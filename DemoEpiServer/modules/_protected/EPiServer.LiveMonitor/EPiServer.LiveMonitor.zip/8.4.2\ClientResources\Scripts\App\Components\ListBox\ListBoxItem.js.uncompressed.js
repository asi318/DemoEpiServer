﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'components/ComponentFactory',
// resources
    'text!components/ListBox/Templates/ExtraInfoListBoxItem.html'
],

function (
// libs
    $,
// live monitor
    utility,

    componentFactory,
// resources
    extraInfoTemplateString
) {

    // =================================================================================================================================================
    // 'LiveMonitorListBoxItem' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/ListBox/LiveMonitorListBoxItem'
    // summary:
    //      The jQuery plugin component for the listbox item
    // description:
    //      use:
    //          $(target).LiveMonitorListBoxItem(options);
    //      options:
    //          resources [Object]
    //          templateString [String]
    //          baseClasses [String]
    //          itemData [Object]
    // tags:
    //      public

    // Create the defaults once
    var pluginName = 'LiveMonitorListBoxItem',
        pluginOptions = {
            templateString: '',
            baseClasses: 'livemonitor-listBoxItem',
            itemData: null
        },
        pluginDefinitions = {

            // =================================================================================================================================================
            // Overrided functions
            // =================================================================================================================================================

            _preInit: function () {
                // summary:
                //      Pre-initialize settings for the component
                // tags:
                //      protected, extension

                var options = this.options,
                    templateString = options.templateString,
                    baseClasses = options.baseClasses,
                    itemData = options.itemData;

                this._$wrapper.addClass(baseClasses);
                if (itemData) {
                    this._injectItemResources(itemData);

                    this._$wrapper.html(utility.formatTemplateString(templateString, itemData));

                    this._injectExtraInfo(itemData);
                    var extraInfo = itemData.extraInfo;
                    if (utility.isValidArray(extraInfo)) {
                        this._appendExtraInfo(extraInfo, /*container*/this._$wrapper.find('.info-item-list'));
                    }
                }
            },

            // =================================================================================================================================================
            // Private functions
            // =================================================================================================================================================

            _injectItemResources: function (/*Object*/itemData) {
                // summary:
                //      Inject resources data to the given source data object
                // itemData: [Object]
                //      The given source data object that want to inject resources to
                // tags:
                //      private

                if (!this._resources || !this._resources.hasOwnProperty('item') || !this._resources.item) {
                    return;
                }

                $.extend(true, itemData, this._resources.item);
            },

            _appendExtraInfo: function (/*Array*/extraInfo, /*Object*/container) {
                // summary:
                //      Append extra information to the list box item
                // extraInfo: [Array]
                //      The given collection of the extra information
                // container: [Object]
                //      The given container
                // tags:
                //      private

                if (!container || container.length === 0) {
                    return;
                }

                var extraInfoResources = this.options.extraInfoResources,
                    fragment = document.createDocumentFragment(),
                    totalItems = extraInfo.length,
                    item;

                while (totalItems--) {
                    item = extraInfo[totalItems];
                    if (!item || !item.key) {
                        continue;
                    }

                    // Append 'name' property
                    item.name = extraInfoResources[item.key];

                    $(utility.formatTemplateString(extraInfoTemplateString, item)).prependTo(fragment);
                }

                container && container.append(fragment);
            }

        };

    // A really lightweight plugin wrapper around the constructor, 
    //  preventing against multiple instantiations
    $.fn[pluginName] = function (/*Object*/options) {
        // summary:
        //      Create a new jQuery plugin from the given settings
        // options: [Object]
        //      The given settings that wanted to decorates the default settings of the current component
        // returns: [Object]
        //      The jQuery plugin object
        // tags:
        //      protected

        // Decorates the default settings by the given settings
        $.extend(true, pluginOptions, options);

        // Create and then return a new jQuery plugin object
        return componentFactory.create(this, pluginName, pluginDefinitions, pluginOptions);
    };

    $.fn[pluginName].prototype.pluginOptions = pluginOptions;
    $.fn[pluginName].prototype.pluginDefinitions = pluginDefinitions;

});