﻿define([
// libs
    'jquery',
// live monitor
    'components/Svg/Factory/Template/BaseTemplate'
],

function (
// libs
    $,
// live monitor
    baseTemplate
) {

    // =================================================================================================================================================
    // 'TransparentBallTemplate' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Svg/Factory/Template/TransparentBallTemplate'
    // summary:
    //      Provides transparent ball content markup template in SVG format
    // description:
    //      Public functions:
    //          load(/*String?*/text)
    //              Load SVG in JSON format
    //          loadExternal()
    //              Load SVG in raw format (SVG markup string)
    // tags:
    //      public

    var TransparentBallTemplate = {

        // key: [String] public
        //      The unique key that used to register to the controller
        //      The controller used this key to identifies each registered template
        key: 'TransparentBall',

        // name: [String] public
        //      The template name that used to register to the controller
        //      The application used this name to display
        name: 'Transparent Ball Template',

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        load: function (/*Decimal?*/radius) {
            // summary:
            //      Get predefined markup settings for a transparent ball SVG object
            // radius: [Decimal?]
            //      The given radius
            // returns: [Object]
            //      The JSON markup settings for a transparent ball SVG object
            // tags:
            //      public

            !radius && (radius = 20);

            return {
                svg: {
                    height: radius * 2,
                    width: radius * 2,
                    g: {
                        classes: 'livemonitor-ball transparent',
                        circle: {
                            cx: radius,
                            cy: radius,
                            r: radius,
                            fill: 'transparent'
                        }
                    }
                }
            };
        }

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

    };

    return $.extend(true, {}, baseTemplate, TransparentBallTemplate);

});