﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'components/ComponentFactory',
// resources
    'text!components/Clock/Templates/Clock.html'
],

function (
// libs
    $,
// live monitor
    utility,

    componentFactory,
// resources
    templateString
) {

    // =================================================================================================================================================
    // 'LiveMonitorClock' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Clock/LiveMonitorClock'
    // summary:
    //      The jQuery plugin component for the clock
    // description:
    //      use:
    //          $(target).LiveMonitorClock(options);
    //      options:
    //          resources [Object]
    //          templateString [String]
    //          baseClasses [String]
    // tags:
    //      public

    // Create the defaults once
    var pluginName = 'LiveMonitorClock',
        pluginOptions = {
            templateString: templateString,
            baseClasses: 'clock digital-clock'
        },
        pluginDefinitions = {

            // =================================================================================================================================================
            // Overrided functions
            // =================================================================================================================================================

            _postInit: function () {
                // summary:
                //      Post-initialize settings for the component
                // tags:
                //      protected, extension

                this._setupLayout();
            },

            // =================================================================================================================================================
            // Private functions
            // =================================================================================================================================================

            _setupLayout: function () {
                // summary:
                //      Initialize default layout settings for the component
                // tags:
                //      private

                this._setCurrentTime();

                setInterval(utility.hitch(this, function () {
                    this._setCurrentTime();
                }), 1000);
            },

            _setCurrentTime: function () {
                // summary:
                //      Set current time
                // tags:
                //      private

                var $digit = this._$wrapper.find('.digit'),
                    $period = this._$wrapper.find('.period'),
                    currentTime = this._getCurrentTime();

                if (currentTime) {
                    $digit.html(currentTime.hours + ':' + currentTime.minutes);
                    $period.html(currentTime.period);
                }
            },

            _getCurrentTime: function () {
                // summary:
                //      Get current time
                // returns: [Object]
                //  format:
                //  { hours: 00, minutes: 00, seconds: 00, period: 'AM'|'PM' }
                //      hours [Integer]
                //      minutes [Integer]
                //      seconds [Integer]
                //      period [String]
                // tags:
                //      private

                var period = this._resources.period,
                    d = new Date(),
                    hh = d.getHours(),
                    m = d.getMinutes(),
                    s = d.getSeconds(),
                    dd = period.am,
                    h = hh;

                if (h >= 12) {
                    h = hh - 12;
                    dd = period.pm;
                }

                if (h == 0) {
                    h = 12;
                }

                m = m < 10 ? '0' + m : m;
                s = s < 10 ? '0' + s : s;
                // 2 digit hours:
                h = h < 10 ? '0' + h : h;

                return {
                    hours: h,
                    minutes: m,
                    seconds: s,
                    period: dd
                };
            }

        };

    // A really lightweight plugin wrapper around the constructor, 
    //  preventing against multiple instantiations
    $.fn[pluginName] = function (/*Object*/options) {
        // summary:
        //      Create a new jQuery plugin from the given settings
        // options: [Object]
        //      The given settings that wanted to decorates the default settings of the current component
        // returns: [Object]
        //      The jQuery plugin object
        // tags:
        //      protected

        // Decorates the default settings by the given settings
        $.extend(true, pluginOptions, options);

        // Create and then return a new jQuery plugin object
        return componentFactory.create(this, pluginName, pluginDefinitions, pluginOptions);
    };

});