﻿define([
// libs
    'jquery',
    'd3',
// live monitor
    'utility',

    'components/Svg/Layout/BaseSvgLayout',

    'components/Svg/Animation/AnimationController',
    'components/Svg/Factory/MarkupController'
],

function (
// libs
    $,
    dataVisualizer,
// live monitor
    utility,

    baseSvgLayout,

    animationController,
    markupController
) {

    // =================================================================================================================================================
    // Component information
    // =================================================================================================================================================
    //
    // module:
    //      Components/Svg/Layout/MultiFociLayout
    // summary:
    //      
    // description:
    //      
    // tags:
    //      public

    var MultiFociLayout = {

        // Default settings for the component
        settings: {
            // Default place holder for the current svg element
            placeHolder: 'body',
            // Default animation animation name
            animationKey: 'fourPathsAnimation'
        },

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        create: function (/*Object*/settings) {
            // summary:
            //      Create a new instance of the component
            // settings: [Object]
            //      The new settings that wanted to decorates the default settings of the given component
            // returns: [Object]
            //      An instance of the component
            // tags:
            //      public

            $.extend(true, this.settings, settings);

            this._createSvg();

            return this;
        },

        bindData: function (/*Object*/multiFociLayoutData) {
            // summary:
            //      Binding the given data to the component and its children
            // multiFociLayoutData: [Object]
            //      The given multi foci layout data object
            //          hierarchicalMappingData: [Array]
            //              The given data that used to mapping a group to a desired position (x,y)
            //              Array item object structure:
            //                  contentId: [String]
            //                  parentContentId: [String]
            //                  x: [Decimal]
            //                  y: [Decimal]
            //          visitorDataList: [Array]
            //              The given data set that wanted to bind to the current component
            //          templateList: [Array]
            //              The given template list
            // tags:
            //      public

            var hierarchicalMappingData = multiFociLayoutData.hierarchicalMappingData,
                visitorDataList = multiFociLayoutData.visitorDataList,
                templateString = multiFociLayoutData.templateString;

            this._fociMappingData = hierarchicalMappingData;
            this._visitorBallTemplateList = templateString.visitorBalls;

            this._updateFociListData(this._fociMappingData);
            this._shouldUpdate(this._fociMappingData) && this._setupCirclePath();

            this._updateVisitorListData(visitorDataList);
            this._setupVisitorListPosition(visitorDataList);
            this._setupVisitorListAnimation(this.settings.animationKey);
        },

        setSelection: function (/*Integer*/visitorNumber) {
            // summary:
            //      Set selection in the current layout by the given identification
            // visitorNumber: [Integer]
            //      The given visitor number
            // tags:
            //      public

            this._setSelectedState(visitorNumber);
        },

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

        _createSvg: function () {
            // summary:
            //      Create the SVG element
            // tags:
            //      private

            this._svg = this._svg || dataVisualizer.select(this.settings.placeHolder).append('svg').attr('class', 'livemonitor-multiFociLayout');
        },

        // =================================================================================================================================================
        // Foci list functions
        // =================================================================================================================================================

        _updateFociListData: function (/*Array*/fociMappingData) {
            // summary:
            //      Update the node collection from the given data
            // fociMappingData: [Array]
            //      The given collection of hierarchical data object
            // tags:
            //      private

            var container = this._svg.select('g#visitor-fociList').node()
                    ? this._svg.select('g#visitor-fociList')
                    : this._svg.append('g').attr('id', 'visitor-fociList');

            // DATA JOIN
            // Join new data with old elements, if any.
            this._fociList = container.selectAll('.visitor-foci')
                .data(fociMappingData, function (/*Object*/d) {
                    // d: [Object]
                    //      The given datum object

                    return d.contentId;
                });

            // UPDATE
            // Update old elements as needed.
            this._fociList.attr('class', 'visitor-foci updated');

            // ENTER
            // Create new elements as needed.
            this._fociList.enter().append('path')
                .attr('class', 'visitor-foci enter')
                .attr('id', function (/*Object*/d) {
                    // d: [Object]
                    //      The given datum object

                    return 'visitor-foci-' + d.contentId;
                });

            // EXIT
            // Remove old elements as needed.
            this._fociList.exit().remove();
        },

        _setupCirclePath: function () {
            // summary:
            //      Setup circle path from the given data
            // tags:
            //      private

            this._fociList.attr('d', function (/*Object*/d) {
                // d: [Object]
                //      The given datum object

                // TODO: Move '20, 40, 80' to a configurable settings
                return 'M {cx} {cy} m -{r}, 0 a {r},{r} 0 1,1 {d},0 a {r},{r} 0 1,1 -{d},0'
                    .replace(/{cx}/g, d.x + 20)
                    .replace(/{cy}/g, d.y + 20)
                    .replace(/{r}/g, 40)
                    .replace(/{d}/g, 80);
            });
        },

        // =================================================================================================================================================
        // Visitor list functions
        // =================================================================================================================================================

        _updateVisitorListData: function (/*Array*/visitorDataList) {
            // summary:
            //      Update the node collection from the given data
            // visitorDataList: [Array]
            //      The given collection of node data object
            // tags:
            //      private

            var container = this._svg.select('g#visitorList').node()
                    ? this._svg.select('g#visitorList')
                    : this._svg.append('g').attr('id', 'visitorList');

            // DATA JOIN
            // Join new data with old elements, if any.
            this._groupList = container.selectAll('.visitor')
                .data(visitorDataList, function (/*Object*/d) {
                    // d: [Object]
                    //      The given datum object

                    return d.number;
                });

            // UPDATE
            // Update old elements as needed.
            this._groupList.attr('class', 'visitor updated');

            // ENTER
            // Create new elements as needed.
            var newGroupList = this._groupList.enter().append('g')
                .attr('class', 'visitor enter')
                .attr('id', function (/*Object*/d) {
                    // d: [Object]
                    //      The given datum object

                    return 'visitor-' + d.number;
                });
            this._setupVisitorListLayout(newGroupList[0]);

            // EXIT
            // Remove old elements as needed.
            this._groupList.exit().remove();
        },

        _setupVisitorListLayout: function (/*Array*/newGroupList) {
            // summary:
            //      Setup layout for the given nodes
            // newGroupList: [Array]
            //      The given collection of the node object
            // tags:
            //      private

            var totalItems = newGroupList.length,
                container,
                containerNode,
                itemData;

            while (totalItems--) {
                container = dataVisualizer.select(newGroupList[totalItems]);
                containerNode = container.node();

                itemData = containerNode && container.datum();
                if (!itemData) {
                    continue;
                }

                containerNode.appendChild(this._getTemplateContent(this._visitorBallTemplateList[totalItems]));
            }
        },

        _setupVisitorListPosition: function (/*Array*/visitorDataList) {
            // summary:
            //      Update position for each group element
            // visitorDataList: [Array]
            //      The given data set that wanted to bind to the current component
            // tags:
            //      private

            $.when(this._setupVisitorsMappingData(visitorDataList))
                .done(utility.hitch(this, function () {
                    this._groupList.transition().duration(400)
                        .attr('transform', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return 'translate(' + d.x + ',' + d.y + ')';
                        });
                }));
        },

        _setupVisitorListAnimation: function (/*String*/animationKey) {
            // summary:
            //      Fired on finished layout process
            // animationKey: [String]
            //      The given animation animation key
            // tags:
            //      private

            var groupList = this._groupList[0];
            if (!utility.isValidArray(groupList)) {
                return;
            }

            var marker,
                delay,
                totalItems = groupList.length;

            while (totalItems--) {
                marker = dataVisualizer.select(groupList[totalItems]);
                if (marker && marker.node()) {
                    delay = totalItems * 5;
                    animationController.load(/*animationKey*/animationKey, marker, delay);
                }
            }
        },

        // =================================================================================================================================================
        // Mapping position functions
        // =================================================================================================================================================

        _setupVisitorsMappingData: function (/*Array*/visitorDataList) {
            // summary:
            //      Setup the given hierarchical mapping data for all nodes
            // visitorDataList: [Array]
            //      The given visitor data collection
            // tags:
            //      private

            if (!utility.isValidArray(visitorDataList)) {
                return;
            }

            var $deferred = $.Deferred(),
                container = this._svg;

            $.when(this._getVisitorFociDataList(visitorDataList))
                .done(function (/*Array*/visitorFociDataList) {
                    if (!utility.isValidArray(visitorFociDataList)) {
                        return;
                    }

                    var totalItems = visitorFociDataList.length,
                        visitorFociData,
                        foci,
                        fociNode,
                        distance,
                        startPoint,
                        totalPoints,
                        pointer;

                    while (totalItems--) {
                        visitorFociData = visitorFociDataList[totalItems];
                        if (visitorFociData.foci && utility.isValidArray(visitorFociData.visitors)) {
                            foci = container.select('path#visitor-foci-' + visitorFociData.foci.contentId);
                            if (foci && (fociNode = foci.node())) {

                                totalPoints = fociNode.getTotalLength();
                                // Start point of the given path
                                startPoint = utility.getRandomNumber(1, totalPoints);
                                // The distance between two visitors
                                distance = totalPoints / visitorFociData.visitors.length;

                                var totalVisitors = visitorFociData.visitors.length,
                                    visitor;
                                while (totalVisitors--) {
                                    visitor = visitorFociData.visitors[totalVisitors];
                                    pointer = fociNode.getPointAtLength(startPoint);
                                    if (pointer) {
                                        // TODO: Move '10' (visitor ball's radius) to a configurable settings
                                        visitorDataList[visitor.index].x = pointer.x - 10;
                                        visitorDataList[visitor.index].y = pointer.y - 10;
                                        visitorDataList[visitor.index].visitorRadius = 10;
                                        visitorDataList[visitor.index].fociBBox = fociNode.getBBox();
                                    }

                                    startPoint += distance;
                                    if (startPoint > totalPoints) {
                                        startPoint = utility.getRandomNumber(1, totalPoints);
                                    }
                                }
                            }
                        }

                        if (totalItems === 0) {
                            $deferred.resolve();
                        }
                    }
                });

            return $deferred.promise();
        },

        _getVisitorFociDataList: function (/*Array*/visitorDataList) {
            // summary:
            //      Get mapping data collection that groups all visitors data to each foci group
            // visitorDataList: [Array]
            //      The given visitor data collection
            // returns: [Object]
            //      An instance of Array class
            //      It is the collection of the mapping data between visitors and foci
            // tags:
            //      private

            var $deferred = $.Deferred();

            if (!utility.isValidArray(visitorDataList)) {
                $deferred.resolve();

                return $deferred.promise();
            }

            var totalItems = visitorDataList.length,
                item,
                visitorFociDataList = [],
                visitorFociData,
                targetFoci;

            while (totalItems--) {
                item = visitorDataList[totalItems];
                if (targetFoci = this._getTargetFoci(item)) {
                    item.index = totalItems;
                    if (visitorFociData = utility.getItemFromCollection(visitorFociDataList, targetFoci, this._visitorFociFilter)) {
                        visitorFociData.visitors.push(item);
                    } else {
                        visitorFociDataList.push({
                            foci: targetFoci,
                            visitors: [item]
                        });
                    }
                }

                if (totalItems === 0) {
                    $deferred.resolve(visitorFociDataList);
                }
            }

            return $deferred.promise();
        },

        _getTargetFoci: function (/*Object*/visitorData) {
            // summary:
            //      Get target foci object of the given visitor data
            // visitorData: [Object]
            //      The given visitor data
            // returns: [Object]
            //      The target foci object that used to mapping the position for the given visitor
            // tags:
            //      private

            if (!visitorData || !visitorData.visit.currentContent) {
                return;
            }

            var filterConditions = {
                contentId: visitorData.visit.currentContent.contentId
            };

            var targetFoci = utility.getItemFromCollection(this._fociMappingData, filterConditions, this._fociFilter);
            if (targetFoci) {
                return targetFoci;
            }

            var ancestorIdList = visitorData.visit.currentContent.ancestorIdList;
            if (!utility.isValidArray(ancestorIdList)) {
                return;
            }

            var totalItems = ancestorIdList.length;
            for (var i = 0; i < totalItems; i++) {
                filterConditions.contentId = ancestorIdList[i];
                targetFoci = utility.getItemFromCollection(this._fociMappingData, filterConditions, this._fociFilter);
                if (targetFoci) {
                    return targetFoci;
                }
            }
        },

        // =================================================================================================================================================
        // Filter functions
        // =================================================================================================================================================

        _visitorFilter: function (/*Object*/source, /*Object*/target) {
            // summary:
            //      Filters by comparing part(s) of the given source and target objects
            // source: [Object]
            //      The given source object
            // target: [Object]
            //      The given target object
            // return: [Boolean]
            // tags:
            //      private

            return source.id == target.id;
        },

        _fociFilter: function (/*Object*/source, /*Object*/target) {
            // summary:
            //      Filters by comparing part(s) of the given source and target objects
            // source: [Object]
            //      The given source object
            // target: [Object]
            //      The given target object
            // return: [Boolean]
            // tags:
            //      private

            return source.contentId == target.contentId;
        },

        _visitorFociFilter: function (/*Object*/source, /*Object*/target) {
            // summary:
            //      Filters by comparing part(s) of the given source and target objects
            // source: [Object]
            //      The given source object
            // target: [Object]
            //      The given target object
            // return: [Boolean]
            // tags:
            //      private

            return source.foci.contentId == target.contentId;
        },

        // =================================================================================================================================================
        // Selection functions
        // =================================================================================================================================================

        _setSelectedState: function (/*Integer*/visitorNumber) {
            // summary:
            //      Applies SELECTED state for the given target
            // visitorNumber: [Integer]
            //      The given number of a visitor
            // tags:
            //      private

            this._clearSelectedState();

            var target = dataVisualizer.select(this._svg.node()).select('#visitor-' + visitorNumber + ' .livemonitor-ball');
            target.classed('selected', true);
            target.select('circle').attr('fill', 'url(#livemonitor-verticalLinearGradient-selected)');
        },

        _clearSelectedState: function () {
            // summary:
            //      Clear SELECTED state of the given target
            // tags:
            //      private

            var target = dataVisualizer.select(this._svg.node()).select('.livemonitor-ball.selected');
            target.classed('selected', false);

            var circle = target.select('circle');
            circle.attr('fill', 'url(#'+ $(circle.node()).data('fill') +')');
        }

    };

    return $.extend(true, {}, baseSvgLayout, MultiFociLayout);

});