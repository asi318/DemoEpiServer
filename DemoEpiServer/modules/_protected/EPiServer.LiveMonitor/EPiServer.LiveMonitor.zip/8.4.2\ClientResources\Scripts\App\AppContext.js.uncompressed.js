﻿define([
// libs
    'jquery'
],

function (
// libs
    $
) {

    // =================================================================================================================================================
    // 'AppContext' class information
    // =================================================================================================================================================
    // module:
    //      'App/AppContext'
    // summary:
    //      An abstract layer to persists application context session data
    // description:
    //      Provides context functions for the application
    //      Public functions:
    //          init()
    //          triggerEvent(/*String*/eventName, /*Object?*/data)
    //          bindEvent(/*String*/eventName, /*Function*/callback)
    //          getReadyConnection()
    //          setReadyConnection(/*Object*/connection)
    //          getSelection()
    //          setSelection(/*Object*/selectionData)
    //          getCache(/*String*/cacheKey)
    //          setCache(/*String*/cacheKey, /*Object*/cacheValue)
    // tags:
    //      public

    var AppContext = {

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        init: function () {
            // summary:
            //      Setup the application context
            // tags:
            //      public

            this._$target = this._$target || $('#wrapper');
        },

        // =================================================================================================================================================
        // EVENT settings functions
        // =================================================================================================================================================

        triggerEvent: function (/*String*/eventName, /*Object?*/data) {
            // summary:
            //      Register and trigger the given event with the application context scope
            // eventName: [String]
            //      The given event name that wanted to register and trigger with the application context scope
            // data: [Object?]
            //      The given data
            // tags:
            //      public

            if (!eventName) {
                return;
            }

            this._$target.trigger(eventName, [data]);
        },

        bindEvent: function (/*String*/eventName, /*Function*/callback) {
            // summary:
            //      Listen on the registered event that registered with application context scope and then fires the given callback function
            // eventName: [String]
            //      The given event name that registered and triggered with application context scope
            // callback: [Function]
            //      The given callback function that wanted to fires when the registered event executed
            // tags:
            //      public

            if (!eventName || !$.isFunction(callback)) {
                return;
            }

            this._$target.bind(eventName, callback);
        },

        // =================================================================================================================================================
        // COMMUNICATOR connection settings functions
        // =================================================================================================================================================

        getReadyConnection: function () {
            // summary:
            //      Get the connection object from store
            // returns: [Object]
            //      The registered connection object
            // tags:
            //      public

            return this._getFromStore('ready-connection');
        },

        setReadyConnection: function (/*Object*/connection) {
            // summary:
            //      Save the given connection object to store
            // connection: [Object]
            //      The given connection object
            // tags:
            //      public

            this._saveToStore('ready-connection', connection);
        },

        // =================================================================================================================================================
        // Selection settings functions
        // =================================================================================================================================================

        getSelection: function () {
            // summary:
            //      Get the selection data object in JSON format from store
            // returns: [Object]
            //      The selection data object in JSON format
            // tags:
            //      public

            return this._getFromStore('selection-data');
        },

        setSelection: function (/*Object*/selectionData) {
            // summary:
            //      Save the given selection data object to store
            // selectionData: [Object]
            //      The given selection data
            // tags:
            //      public

            this._saveToStore('selection-data', selectionData);
        },

        // =================================================================================================================================================
        // Cache settings functions
        // =================================================================================================================================================

        getCache: function (/*String*/cacheKey) {
            // summary:
            //      Get cached value from store by the given cache key
            // cacheKey: [String]
            //      The given cache key
            // returns: [Object]
            //      The cached object that got by the given cache key
            // tags:
            //      public

            return this._getFromStore(cacheKey);
        },

        setCache: function (/*String*/cacheKey, /*Object*/cacheValue) {
            // summary:
            //      Save cache object to store by the given key and value
            // cacheKey: [String]
            //      The given cache key
            // cacheValue: [Object]
            //      The given cache value object
            // tags:
            //      public

            this._saveToStore(cacheKey, cacheValue);
        },

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

        _getFromStore: function (/*String*/key) {
            // summary:
            //      Get the value from the indicated store by the given key
            // key: [String]
            //      The given key
            // returns: [Object]
            //      The selection data object in JSON format
            // tags:
            //      private

            if (!this._$target || !this._$target[0]) {
                return;
            }

            return $.data(this._$target[0], key);
        },

        _saveToStore: function (/*String*/key, /*Object*/value) {
            // summary:
            //      Save the given key/value pair to the indicated store
            // key: [String]
            //      The given key
            // value: [Object]
            //      The given value
            // tags:
            //      private

            if (!this._$target || !this._$target[0]) {
                return;
            }

            $.data(this._$target[0], key,
                $.type(value) === 'string'
                    ? value
                    : $.extend(true, this._getFromStore(key), value));
        }
    };

    AppContext.init();

    return AppContext;

});