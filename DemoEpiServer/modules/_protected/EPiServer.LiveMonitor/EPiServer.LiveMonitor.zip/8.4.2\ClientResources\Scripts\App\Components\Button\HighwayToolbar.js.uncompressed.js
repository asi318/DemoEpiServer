﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'components/ComponentFactory',

    'components/Button/RadioButton',
    'components/Button/RadioButtonGroup'
],

function (
// libs
    $,
// live monitor
    utility,

    componentFactory,

    radioButton,
    radioButtonGroup
) {

    // =================================================================================================================================================
    // 'LiveMonitorHighwayToolbar' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Button/LiveMonitorHighwayToolbar'
    // summary:
    //      The jQuery plugin component for the highway toolbar
    // description:
    //      use:
    //          $(target).LiveMonitorHighwayToolbar(options);
    // options:
    //          resources [Object]
    // tags:
    //      public

    // Create the defaults once
    var pluginName = 'LiveMonitorHighwayToolbar',
        pluginDefinitions = {

            // =================================================================================================================================================
            // Overrided functions
            // =================================================================================================================================================

            _postInit: function () {
                // summary:
                //      Post-initialize settings for the component
                // tags:
                //      protected, extension

                this._setupLayout();
                this._setupEvents();

                this._setDefaultSelection();
            },

            // =================================================================================================================================================
            // Private functions
            // =================================================================================================================================================

            _setupLayout: function () {
                // summary:
                //      Initialize default layout settings for the current component and its children
                // tags:
                //      private

                var groupName = 'highwayoptions';

                this._$offRadioButton = $('<label></label>').LiveMonitorRadioButton({
                    resources: this._resources.buttons.off,
                    groupName: groupName
                });

                this._$fromPageRadioButton = $('<label></label>').LiveMonitorRadioButton({
                    resources: this._resources.buttons.frompage,
                    groupName: groupName
                });

                this._$toPageRadioButton = $('<label></label>').LiveMonitorRadioButton({
                    resources: this._resources.buttons.topage,
                    groupName: groupName
                });

                this._$globalRadioButton = $('<label></label>').LiveMonitorRadioButton({
                    resources: this._resources.buttons.global,
                    groupName: groupName
                });

                var $highwayRadioButtonGroup = $('<div></div>').LiveMonitorRadioButtonGroup({
                    resources: this._resources,
                    children: [this._$offRadioButton, this._$fromPageRadioButton, this._$toPageRadioButton, this._$globalRadioButton]
                });

                this._$wrapper.append($highwayRadioButtonGroup);
            },

            _setupEvents: function () {
                // summary:
                //      Setup events for the current component and its children
                // tags:
                //      private

                this._$offRadioButton.on('click', utility.hitch(this, function () {
                    this.setContextSelection({
                        highwayMode: 'off'
                    });

                    this.triggerContextEvent('clearHighways');
                }));

                this._$fromPageRadioButton.on('click', utility.hitch(this, function () {
                    this.setContextSelection({
                        highwayMode: 'from'
                    });

                    this.triggerContextEvent('renderHighways');
                }));

                this._$toPageRadioButton.on('click', utility.hitch(this, function () {
                    this.setContextSelection({
                        highwayMode: 'to'
                    });

                    this.triggerContextEvent('renderHighways');
                }));

                this._$globalRadioButton.on('click', utility.hitch(this, function () {
                    this.setContextSelection({
                        highwayMode: 'global'
                    });

                    this.triggerContextEvent('renderHighways');
                }));
            },

            _setDefaultSelection: function () {
                // summary:
                //      Set default selection for the current component
                // tags:
                //      private

                $.isFunction(this._$offRadioButton.button)
                    && this._$offRadioButton.button('toggle');

                $.isFunction(this._$offRadioButton.click)
                    && this._$offRadioButton.click();
            }
        };

    // A really lightweight plugin wrapper around the constructor, 
    //  preventing against multiple instantiations
    $.fn[pluginName] = function (/*Object*/options) {
        // summary:
        //      Create a new jQuery plugin from the given settings
        // options: [Object]
        //      The given settings that wanted to decorates the default settings of the current component
        // returns: [Object]
        //      The jQuery plugin object
        // tags:
        //      protected

        // Create and then return a new jQuery plugin object
        return componentFactory.create(this, pluginName, pluginDefinitions, options);
    };

});