﻿define([
// libs
    'jquery',
    'd3',
// live monitor
    'utility',

    'components/ComponentFactory',

    'components/Svg/ExternalTemplatePreloader',

    'components/ListBox/ListBoxItem',
// resources
    'text!components/ListBox/Templates/OnlineVisitorsListBoxItem.html'
],

function (
// libs
    $,
    dataVisualizer,
// live monitor
    utility,

    componentFactory,

    externalTemplatePreloader,

    listBoxItem,
// resources
    templateString
) {

    // =================================================================================================================================================
    // 'LiveMonitorOnlineVisitorsListBoxItem' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/ListBox/LiveMonitorOnlineVisitorsListBoxItem'
    // summary:
    //      The jQuery plugin component for the online visitors listbox item
    // description:
    //      use:
    //          $(target).LiveMonitorOnlineVisitorsListBoxItem(options);
    //      options:
    //          resources [Object]
    //          templateString [String]
    //          itemData [Object]
    //          itemIdPrefix [String]
    //          itemIdField [String]
    // tags:
    //      public

    // Create the defaults once
    var pluginName = 'LiveMonitorOnlineVisitorsListBoxItem',
        pluginOptions = {
            templateString: templateString,
            itemIdPrefix: 'online-visitor',
            itemIdField: 'number'
        },
        pluginDefinitions = {

            // _visitorBallSvgTemplateKey: [String] private
            //      The key that used to get information about visitor ball
            _visitorBallSvgTemplateKey: 'VisitorBall',

            // =================================================================================================================================================
            // Overrided functions
            // =================================================================================================================================================

            _postInit: function () {
                // summary:
                //      Post-initialize settings for the component
                // tags:
                //      protected, extension

                this._itemData = this.options.itemData;

                this._$icon = this._$wrapper.find('.item-icon .icon');

                this._setupLayout();
                this._setupEvents();
            },

            // =================================================================================================================================================
            // Public functions
            // =================================================================================================================================================

            toggleSelectedState: function (/*Boolean*/selected) {
                // summary:
                //      Applies SELECTED state for the given target
                // selected: [Boolean]
                //      The given BOOLEAN value to indicates the state of selection
                // tags:
                //      public

                this._$wrapper.parent().toggleClass('selected', selected);

                var visitorIcon = dataVisualizer.select(this._svg).select('.livemonitor-ball');
                visitorIcon.classed('selected', selected)
                    .attr('transform', selected
                        ? 'scale(1.3)'
                        : 'scale(1)');

                var circle = visitorIcon.select('circle');
                circle.attr('fill', selected
                    ? 'url(#livemonitor-verticalLinearGradient-selected)'
                    : 'url(#' + $(circle.node()).data('fill') + ')');

                if (selected) {
                    this.setContextSelection({
                        onlineVisitorId: this._getId()
                    });

                    this.triggerContextEvent('onlineVisitorSelected', {
                        visitorNumber: this._itemData.number
                    });
                }
            },

            // =================================================================================================================================================
            // Private functions
            // =================================================================================================================================================

            _setupLayout: function () {
                // summary:
                //      Setup layout for the current component
                // tags:
                //      private

                this._$wrapper.attr('id', this._getId());

                this._setupVisitorBall();
            },

            _setupEvents: function () {
                // summary:
                //      Setup events for the current component
                // tags:
                //      private

                var sender = this;
                this._$wrapper.on('click', function () {
                    $(this).trigger('childSelected', [sender]);
                });
            },

            _setupVisitorBall: function () {
                // summary:
                //      Setup visitor ball from the given template string
                // tags:
                //      private

                $.when(externalTemplatePreloader.getTemplate(this._visitorBallSvgTemplateKey))
                    .done(utility.hitch(this, function (/*String*/templateString) {
                        this._injectChannelInfo(this._itemData);

                        var $svg = $(utility.formatTemplateString(templateString, this._itemData));
                        this._$icon && this._$icon.append(this._svg = $svg[0]);
                    }));
            },

            _getId: function () {
                // summary:
                //      Get unique identification for the current component
                // returns: [String]
                //      The unique identification string
                // tags:
                //      private

                var itemIdPrefix = this.options.itemIdPrefix,
                    itemIdField = this.options.itemIdField;

                return itemIdPrefix + '-' + this._itemData[itemIdField];
            }
        };

    // A really lightweight plugin wrapper around the constructor, 
    //  preventing against multiple instantiations
    $.fn[pluginName] = function (/*Object*/options) {
        // summary:
        //      Create a new jQuery plugin from the given settings
        // options: [Object]
        //      The given settings that wanted to decorates the default settings of the current component
        // returns: [Object]
        //      The jQuery plugin object
        // tags:
        //      protected

        // Decorates the default settings by the given settings
        var basePrototype = $.fn['LiveMonitorListBoxItem'].prototype,
            concreteOptions = $.extend(true, {}, basePrototype.pluginOptions, pluginOptions, options),
            concreteDefinitions = $.extend(true, {}, basePrototype.pluginDefinitions, pluginDefinitions);

        // Create and then return a new jQuery plugin object
        return componentFactory.create(this, pluginName, concreteDefinitions, concreteOptions);
    };

});