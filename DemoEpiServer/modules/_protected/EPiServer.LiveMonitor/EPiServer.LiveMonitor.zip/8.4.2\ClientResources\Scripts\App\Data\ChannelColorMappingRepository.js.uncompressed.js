﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'data/TransferRepository'
],

function (
// libs
    $,
// live monitor
    utility,

    transferRepository
) {

    // =================================================================================================================================================
    // 'ChannelColorMappingRepository' class information
    // =================================================================================================================================================
    // module:
    //      'App/Data/ChannelColorMappingRepository'
    // summary:
    //      The repository for channel color mapping
    // description:
    //      By default:
    //          'red' color mapped for the 'mobile' channel
    //          'blue' color mapped for the 'web' channel
    //      The new channel will automatically mapping with the color in following order:
    //          'orange', 'green', 'turquoise' and 'yellow'
    //      Public functions:
    //          getColorByChannel(/*String*/channel)
    //          setColorByChannel(/*String*/channel)
    // Data:
    //      channelColorMappingData = {
    //          'red': 'mobile',
    //          'blue': 'web',
    //          'orange': '',
    //          'green': '',
    //          'turquoise': '',
    //          'yellow': ''
    //      }
    // tags:
    //      public

    var ChannelColorMappingRepository = {

        // _dataKey: [String]
        //      The channel-color mapping data
        _dataKey: 'channelColorMappingData',

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        getColorByChannel: function (/*String*/channel) {
            // summary:
            //      Get color for the given channel
            // channel: [String]
            //      The given channel name
            // returns: [String]
            //      The color schema name
            // tags:
            //      public

            if (!channel || !this._storage) {
                return;
            }

            var existingData = this._getExistingData();
            if (!existingData) {
                return;
            }

            var color;
            $.each(existingData, function (key, value) {
                if ($.type(value) === 'string' && value.toLowerCase() === channel.toLowerCase()) {
                    color = key;

                    return false;
                }
            });

            return color;
        },

        setColorByChannel: function (/*String*/channel) {
            // summary:
            //      Set color for the given channel
            // channel: [String]
            //      The given channel name
            // tags:
            //      public

            if (!channel || !this._storage) {
                return;
            }

            var existingData = this._getExistingData();
            if (!existingData) {
                return;
            }

            $.each(existingData, utility.hitch(this, function (key, value) {
                if ($.type(value) === 'string' && value.length === 0) {
                    existingData[key] = channel;

                    return false;
                }
            }));
        },

        // =================================================================================================================================================
        // Overrided functions
        // =================================================================================================================================================

        _onInit: function () {
            // summary:
            //      Initialization settings
            // tags:
            //      protected, extensions

            if (!this.getData()) {
                this._setupDefaultData();
            }
        },

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

        _getExistingData: function () {
            // summary:
            //      Get the stored channel-color mapping data
            // returns: [Object]
            //      The stored channel-color mapping data
            // tags:
            //      private

            var existingData = this.getData();
            if (!existingData) {
                this._setupDefaultData();
                existingData = this.getData();
            }

            return existingData;
        },

        _setupDefaultData: function () {
            // summary:
            //      Setup default data
            // tags:
            //      private

            var channelColorMappingData = {
                'blue': 'web',
                'red': 'mobile',
                'orange': '',
                'green': '',
                'turquoise': '',
                'yellow': ''
            };

            this.saveData(channelColorMappingData);
        }

    };

    var channelColorMappingRepository = $.extend(true, {}, transferRepository, ChannelColorMappingRepository);
    channelColorMappingRepository.init();

    return channelColorMappingRepository;

});