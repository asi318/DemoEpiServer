﻿define([
// libs
    'jquery',
// live monitor
    'components/ComponentFactory',

    'components/ListBox/ListBoxItem',
// resources
    'text!components/ListBox/Templates/HistoryVisitorsListBoxItem.html'
],

function (
// libs
    $,
// live monitor
    componentFactory,

    listBoxItem,
// resources
    templateString
) {

    // =================================================================================================================================================
    // 'LiveMonitorHistoryVisitorsListBoxItem' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/ListBox/LiveMonitorHistoryVisitorsListBoxItem'
    // summary:
    //      The jQuery plugin component for the history visitors listbox item
    // description:
    //      use:
    //          $(target).LiveMonitorHistoryVisitorsListBoxItem(options);
    //      options:
    //          resources [Object]
    //          templateString [String]
    //          itemData [Object]
    //          itemIdPrefix [String]
    //          itemIdField [String]
    // tags:
    //      public

    // Create the defaults once
    var pluginName = 'LiveMonitorHistoryVisitorsListBoxItem',
        pluginOptions = {
            templateString: templateString,
            itemIdPrefix: 'history-visitor',
            itemIdField: 'number'
        };

    // A really lightweight plugin wrapper around the constructor, 
    //  preventing against multiple instantiations
    $.fn[pluginName] = function (/*Object*/options) {
        // summary:
        //      Create a new jQuery plugin from the given settings
        // options: [Object]
        //      The given settings that wanted to decorates the default settings of the current component
        // returns: [Object]
        //      The jQuery plugin object
        // tags:
        //      protected

        // Decorates the default settings by the given settings
        var basePrototype = $.fn['LiveMonitorListBoxItem'].prototype,
            concreteOptions = $.extend(true, {}, basePrototype.pluginOptions, pluginOptions, options);

        // Create and then return a new jQuery plugin object
        return componentFactory.create(this, pluginName, basePrototype.pluginDefinitions, concreteOptions);
    };

});