﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'app/AppSettings',
    'app/AppContext',

    'data/ChannelColorMappingRepository',

    'services/CommunicatorController'
],

function (
// libs
    $,
// live monitor
    utility,

    appSettings,
    appContext,

    channelColorMappingRepository,

    communicatorController
) {

    // =================================================================================================================================================
    // BaseComponent class
    // =================================================================================================================================================

    var BaseComponent = {

        // =================================================================================================================================================
        // Private properties
        // =================================================================================================================================================

        _defaultVerticalLinearGradientDefsId: 'livemonitor-verticalLinearGradient',

        // =================================================================================================================================================
        // Public properties
        // =================================================================================================================================================

        // The default settings for the current component
        defaults: {
            // templateString: [String]
            //      The default HTML template string for the current component
            //      Ex: '<div></div>'
            templateString: '',
            // baseClasses: [String]
            //      The default CSS classes for the current component
            //      Each CSS class name should be separated by a space (' ') character
            //      Ex: 'class1 class2'
            baseClasses: '',
            // notifier: [String]
            //      The sub class name of the Communicator class that make notification actions
            notifier: '',
            // notifierCallback: [String]
            //      The callback function name of the given notifier class
            notifierCallback: '',
            // sender: [String]
            //      The sub class name of the Communicator class that make request actions
            sender: '',
            // senderCallback: [String]
            //      The callback function name of the given sender class
            senderCallback: ''
        },

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        setup: function (/*Object*/element, /*Object*/options, /*String*/pluginName) {
            // summary:
            //      Place initialization logic here
            //      You already have access to the DOM element and the options via the instance, e.g. this.element and this.options
            // element: [Object]
            //      The given element
            // options: [Object]
            //      The given options that will be used to decorates the default options
            // pluginName: [String]
            //      The given plugin name
            // tags:
            //      public

            this.element = element;
            this._$wrapper = $(this.element);

            // jQuery has an extend method that merges the 
            //  contents of two or more objects, storing the 
            //  result in the first object. The first object 
            //  is generally empty because we don't want to alter 
            //  the default options for future instances of the component
            this.options = $.extend(true, {}, this.defaults, options);

            this._resources = this.options.resources;

            // Setup application settings
            this._appSettings = appSettings;

            // Setup application context
            this._appContext = appContext;

            this._setPluginName(pluginName);

            this._preInit();
            this._setupCommunication();
            this._postInit();

            var children = this.options.children;
            utility.isValidArray(children) && this._addChildren(children);
        },

        send: function (/*[Array] requestParams, [Function] receiveCallback*/) {
            // summary:
            //      Call a function in server in order to get desired information
            // requestParams: [Array]
            //      The given collection of the request parameter
            // receiveCallback: [Function]
            //      The given receive callback function
            // tags:
            //      public

            if (!this._communicator || !this.options.sender || !this.options.senderCallback) {
                return;
            }

            var sender = this._communicator.sender[this.options.sender],
                senderCallback = this.options.senderCallback;

            if (!sender || !$.isFunction(sender[senderCallback])) {
                return;
            }

            // Get saved connection if it is existing, otherwise create a new connection and then save it
            var ready = this._appContext.getReadyConnection();
            if (!ready) {
                this._appContext.setReadyConnection(this._communicator.connectionReady());
                ready = this._appContext.getReadyConnection();
            }

            var customSendReceive,
                requestParams,
                receiveCallback;

            // Verify this is a custom send/receive
            customSendReceive = (arguments.length === 2)
                    && $.isArray(arguments[0])
                    && $.isFunction(arguments[1]);

            if (customSendReceive) {
                requestParams = arguments[0];
                receiveCallback = arguments[1];
            }

            var requestArguments = customSendReceive
                    ? requestParams
                    : utility.getCollectionFromObject(arguments);

            var requiredParameters = {
                languageId: this._getLanguageId() == '' ? null : this._getLanguageId()
            };
            // Append common required parameters
            if (!utility.isValidArray(requestArguments) || !requestArguments[0]) {
                requestArguments = [requiredParameters];
            } else {
                $.extend(true, requestArguments[0], requiredParameters);
            }

            ready.done(utility.hitch(this, function () {
                sender[senderCallback].apply(sender, requestArguments).done(utility.hitch(this, function () {
                    customSendReceive
                        ? receiveCallback(arguments)
                        : this.onReceiveCompleted.apply(this, arguments);
                }));
            }));
        },

        toggleVisibility: function (/*Boolean*/visible) {
            // summary:
            //      Toggle the visibility of the current component
            // visible: [Boolean]
            //      Flag to indicate the visibility for the current component
            // tags:
            //      public

            this._$wrapper && this._$wrapper.css('visibility', visible ? 'visible' : 'hidden');
        },

        getState: function () {
            // summary:
            //      Get state of the current component
            // returns: [String]
            //      The current state string
            // tags:
            //      public

            return this._currentState;
        },

        setState: function (/*String*/state) {
            // summary:
            //      Set state for the current component
            // state: [String]
            //      Can be:
            //          'sleep'
            // tags:
            //      public

            if ($.type(state) !== 'string') {
                return;
            }

            this._currentState = state;
        },

        // =================================================================================================================================================
        // Settings functions
        // =================================================================================================================================================

        resetSettings: function () {
            // summary:
            //      Restore all application settings to the pre-defined settings values
            // tags:
            //      public

            this._appSettings.resetToDefault();
        },

        registerSetting: function (/*Object*/setting) {
            // summary:
            //      Register the given setting to the application settings
            // setting: [Object]
            //      The given setting information in key/value pair format
            //          key: [String]
            //          value: [Object]
            // tags:
            //      public

            this._appSettings.registerSetting(setting);
        },

        getSettingKeyList: function () {
            // summary:
            //      Get all application registered settings
            // returns: [Array]
            //      The registered application settings key collection
            // tags:
            //      public

            return this._appSettings.getSettingKeyList();
        },

        getSettingValues: function (/*String*/settingKey) {
            // summary:
            //      Get the setting value from the given setting key
            // settingKey: [String]
            //      The given setting key
            // returns: [Array]
            //      The setting value collection that got from the given setting key
            // tags:
            //      public

            return this._appSettings.getSettingValues(settingKey);
        },

        getSetting: function (/*String*/settingKey) {
            // summary:
            //      Get the setting value from the given setting key
            // settingKey: [String]
            //      The given setting key
            // returns: [Object]
            //      The setting value that got from the given setting key
            // tags:
            //      public

            return this._appSettings.getSetting(settingKey);
        },

        // =================================================================================================================================================
        // Selection settings functions
        // =================================================================================================================================================

        setContextSelection: function (/*Object*/selectionData) {
            // summary:
            //      Save the given selection data object to store
            // selectionData: [Object]
            //      The given selection data
            // tags:
            //      public

            this._appContext.setSelection(selectionData);
        },

        getContextSelection: function () {
            // summary:
            //      Get the selection data object in JSON format from store
            // returns: [Object]
            //      The selection data object in JSON format
            // tags:
            //      public

            return this._appContext.getSelection();
        },

        triggerContextEvent: function (/*String*/eventName, /*Object?*/data) {
            // summary:
            //      Register and trigger the given event with the application context scope
            // eventName: [String]
            //      The given event name that wanted to register and trigger with the application context scope
            // data: [Object?]
            //      The given data
            // tags:
            //      public

            this._appContext.triggerEvent(eventName, data);
        },

        bindContextEvent: function (/*String*/eventName, /*Function*/callback) {
            // summary:
            //      Listen on the registered event that registered with application context scope and then fires the given callback function
            // eventName: [String]
            //      The given event name that registered and triggered with application context scope
            // callback: [Function]
            //      The given callback function that wanted to fires when the registered event executed
            // tags:
            //      public

            this._appContext.bindEvent(eventName, callback);
        },

        // =================================================================================================================================================
        // Cache settings functions
        // =================================================================================================================================================

        getCache: function (/*String*/cacheKey) {
            // summary:
            //      Get cached value from store by the given cache key
            // cacheKey: [String]
            //      The given cache key
            // returns: [Object]
            //      The cached object that got by the given cache key
            // tags:
            //      public

            return this._appContext.getCache(cacheKey);
        },

        setCache: function (/*String*/cacheKey, /*Object*/cacheValue) {
            // summary:
            //      Save cache object to store by the given key and value
            // cacheKey: [String]
            //      The given cache key
            // cacheValue: [Object]
            //      The given cache value object
            // tags:
            //      public

            this._appContext.setCache(cacheKey, cacheValue);
        },

        // =================================================================================================================================================
        // Public callback functions
        // =================================================================================================================================================

        layout: function () {
            // summary:
            //      Layout the current component
            // tags:
            //      public, callback
        },

        bindData: function (/*Object*/data) {
            // summary:
            //      Executes binding the given data to the current component and|or its children
            // data: [Object]
            //      The given data used to binding
            // tags:
            //      public, callback
        },

        onPreInit: function () {
            // summary:
            //      Fired while the current component in the pre-init state and before post-init
            // tags:
            //      public, callback
        },

        onNotified: function () {
            // summary:
            //      Fired when had any change in server side
            // tags:
            //      public, callback
        },

        onReceiveCompleted: function () {
            // summary:
            //      Fired after client requested to server and then server responsed
            // tags:
            //      public, callback
        },

        // =================================================================================================================================================
        // Protected callback functions
        // =================================================================================================================================================

        _onGetListSelector: function (/*String*/defaultSelector) {
            // summary:
            //      Place to modify the selector of the list container
            // defaultSelector: [String]
            //      The given selector by default
            // returns: [String]
            //      The selector string
            // tags:
            //      protected, extensions

            return defaultSelector;
        },

        _onAddChild: function (/*Object*/child) {
            // summary:
            //      Place to decorates the given child element
            // child: [Object]
            //      The given child element that want to decorates
            // tags:
            //      protected, extensions
        },

        // =================================================================================================================================================
        // Protected functions
        // =================================================================================================================================================

        _preInit: function () {
            // summary:
            //      Pre-initialize settings for the component
            // tags:
            //      protected, extension

            var templateString = this.options.templateString,
                baseClasses = this.options.baseClasses,
                children = this.options.children;

            baseClasses && this._$wrapper.addClass(baseClasses);
            templateString && this._$wrapper.html(templateString);

            this.onPreInit();
        },

        _postInit: function () {
            // summary:
            //      Post-initialize settings for the component
            // tags:
            //      protected, extension
        },

        _addChildren: function (/*Array*/children) {
            // summary:
            //      Create new children and then append them to the given container if any
            // children: [Array]
            //      The collection of the object that want to build as the child component of the current component
            // tags:
            //      protected, extensions

            if (!utility.isValidArray(children)) {
                return;
            }

            var $listContainer = $(this._onGetListSelector('.item-list'), this._$wrapper),
                totalItems = children.length,
                item;

            while (totalItems--) {
                item = children[totalItems];
                if (!item || !$(item)) {
                    continue;
                }

                this._onAddChild($(item).prependTo($listContainer));
            }
        },

        _getTemplateString: function (/*Object*/element) {
            // summary:
            //      Get outer HTML string from the given DOM element
            // element: [Object]
            //      The given DOM element
            // returns: [String]
            //      The template in the string format
            // tags:
            //      protected

            return utility.getOuterContent(element);
        },

        _getLanguageId: function () {
            // summary:
            //      Get the setting language id
            // tags:
            //      protected

            if (this._languageId != null) {
                return this._languageId;
            }

            this._languageId = utility.getURLParameter('languageId');
            if (this._languageId != null) {
                return this._languageId;
            }

            return this._languageId = this.getSetting('languageId');
        },

        _injectChannelInfo: function (/*Object*/data) {
            // summary:
            //      Inject channel information to the given data object
            // data: [Object]
            //      The given data object
            // tags:
            //      protected

            if (!data) {
                return;
            }

            if (!data.propertyBag || !data.propertyBag.channel) {
                data.linearGradientDefsId = this._defaultVerticalLinearGradientDefsId;
            }

            var channel = data.propertyBag.channel,
                channelColor = channelColorMappingRepository.getColorByChannel(channel);

            if (!channelColor) {
                channelColorMappingRepository.setColorByChannel(channel);
            }

            var linearGradientDefsId = channel == null
                    ? this._defaultVerticalLinearGradientDefsId
                    : this._defaultVerticalLinearGradientDefsId + '-' + channelColor,
                $linearGradientDefElement = $('#' + linearGradientDefsId);

            data.channel = channelColor;
            data.linearGradientDefsId = $linearGradientDefElement && $linearGradientDefElement.length > 0
                ? linearGradientDefsId
                : this._defaultVerticalLinearGradientDefsId;
        },

        _injectExtraInfo: function (/*Object*/data) {
            // summary:
            //      Inject extra information to the given data object
            // data: [Object]
            //      The given data object
            // tags:
            //      protected

            if (!data || !data.propertyBag) {
                return;
            }

            data.extraInfo = [];
            $.each(data.propertyBag, function (key, value) {
                if (value == null) {
                    return;
                }

                data.extraInfo.push({
                    key: key,
                    value: value
                });
            });
        },

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

        _setupCommunication: function () {
            // summary:
            //      Setup communication between client and server
            // tags:
            //      private

            if (!this._appSettings) {
                return;
            }

            // Setup application communicator
            this._communicator = communicatorController.getCommunicator(this._appSettings.getSetting('communicator'));
            if (!this._communicator || !this.options.notifierCallback) {
                return;
            }

            var notifier = this._communicator.notifier,
                notifierCallback = this.options.notifierCallback;

            if (!notifier || !$.isFunction(notifier[notifierCallback])) {
                return;
            }

            notifier[notifierCallback] = utility.hitch(this, function () {
                this.onNotified.apply(this, arguments);
            });
        },

        _setPluginName: function (/*String*/pluginName) {
            // summary:
            //      Set the plugin name to the container HTML5 'data-' attribute
            // pluginName: [String]
            //      The given plugin name
            // tags:
            //      private

            pluginName && $.data(this.element, 'plugin-name', pluginName);
        }

    };

    return BaseComponent;

});