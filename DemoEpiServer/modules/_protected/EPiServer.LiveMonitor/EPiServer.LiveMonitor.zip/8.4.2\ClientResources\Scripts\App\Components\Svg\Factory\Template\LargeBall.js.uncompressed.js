﻿define([
// libs
    'jquery',
// live monitor
    'components/Svg/Factory/Template/BaseTemplate'
],

function (
// libs
    $,
// live monitor
    baseTemplate
) {

    // =================================================================================================================================================
    // 'LargeBallTemplate' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Svg/Factory/Template/LargeBallTemplate'
    // summary:
    //      Provides large ball content markup template in SVG format
    // description:
    //      Public functions:
    //          load(/*String?*/text)
    //              Load SVG in JSON format
    //          loadExternal()
    //              Load SVG in raw format (SVG markup string)
    // tags:
    //      public

    var LargeBallTemplate = {

        // key: [String] public
        //      The unique key that used to register to the controller
        //      The controller used this key to identifies each registered template
        key: 'LargeBall',

        // name: [String] public
        //      The template name that used to register to the controller
        //      The application used this name to display
        name: 'Large Ball Template',

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        load: function (/*String?*/text) {
            // summary:
            //      Get predefined markup settings for a large ball SVG object
            // text: [String?]
            //      The given text that wanted to bind to the 'text' SVG tag
            // returns: [Object]
            //      The JSON markup settings for a large ball SVG object
            // tags:
            //      public

            return {
                svg: {
                    height: 40,
                    width: 40,
                    g: {
                        classes: 'livemonitor-ball large',
                        circle: {
                            cx: 20,
                            cy: 20,
                            r: 20,
                            fill: 'url(#livemonitor-verticalLinearGradient)'
                        },
                        ellipse: {
                            cx: 20,
                            cy: 13,
                            rx: 15,
                            ry: 10
                        },
                        text: {
                            classes: 'number',
                            x: 10,
                            y: 13,
                            value: text
                        }
                    }
                }
            };
        }

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

    };

    return $.extend(true, {}, baseTemplate, LargeBallTemplate);

});