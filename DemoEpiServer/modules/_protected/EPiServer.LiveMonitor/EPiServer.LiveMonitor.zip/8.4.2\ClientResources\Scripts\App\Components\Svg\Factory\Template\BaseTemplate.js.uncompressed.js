﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'app/AppSettings'
],

function (
// libs
    $,
// live monitor
    utility,

    appSettings
) {

    // =================================================================================================================================================
    // 'BaseTemplate' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Svg/Factory/Template/BaseTemplate'
    // summary:
    //      The base class for application template loader
    // description:
    //      Public functions:
    //          load(/*String?*/text)
    //              Load SVG in JSON format
    //          loadExternal()
    //              Load SVG in raw format (SVG markup string)
    // tags:
    //      public

    var BaseTemplate = {

        // key: [String] public
        //      The unique key that used to register to the controller
        //      The controller used this key to identifies each registered template
        key: 'BaseTemplate',

        // name: [String] public
        //      The template name that used to register to the controller
        //      The application used this name to display
        name: 'Base Template',

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        load: function (/*String?*/text) {
            // summary:
            //      Get predefined markup settings for a small ball SVG object
            // text: [String?]
            //      The given text that wanted to bind to the 'text' SVG tag
            // returns: [Object]
            //      The JSON markup settings for a small ball SVG object
            // tags:
            //      public, extension

        },

        loadExternal: function () {
            // summary:
            //      Load an external SVG file by the given theme
            // returns: [String]
            //      The external SVG content template string
            // tags:
            //      public

            var $deferred = $.Deferred(),
                externalFileUrl = utility.buildPath([
                    appSettings.getSetting('themesRootPath'),
                    appSettings.getSetting('theme'),
                    'Svg',
                    this.key + '.min.svg'
                ]);

            $.when(utility.loadSvgFile(externalFileUrl))
                .done(utility.hitch(this, function (/*Object*/documentElement) {
                    $deferred.resolve($(documentElement).clone()[0]);
                }));

            return $deferred.promise();
        }

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

    };

    return BaseTemplate;

});