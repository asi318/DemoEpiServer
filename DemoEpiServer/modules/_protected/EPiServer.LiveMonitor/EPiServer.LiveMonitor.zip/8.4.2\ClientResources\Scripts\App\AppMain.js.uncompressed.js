﻿define([
// libs
    'jquery',
    'bootstrap',
// live monitor
    'utility',

    'app/AppSettings',

    'services/CommunicatorController',
    'services/Communicator',

    'components/Svg/Animation/AnimationController',

    'components/Svg/Animation/Effect/Simple',
    'components/Svg/Animation/Effect/HeartBeat',
    'components/Svg/Animation/Effect/Satellite',
    'components/Svg/Animation/Effect/Vibration',

    'components/Container/Dashboard'
],

function (
// libs
    $,
    bootstrap,
// live monitor
    utility,

    appSettings,

    communicatorController,
    communicator,

    animationController,

    simpleAnimation,
    heartBeatAnimation,
    satelliteAnimation,
    vibrationAnimation,

    dashboard
) {

    // =================================================================================================================================================
    // 'AppMain' class
    // =================================================================================================================================================
    //
    // module:
    //      Components/AppMain
    // summary:
    //      
    // description:
    //      
    // tags:
    //      public

    var AppMain = {

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        init: function () {
            // summary:
            //      Initialization for the current component
            // tags:
            //      public

            this._config = LiveMonitorConfig;

            var registerDeferredList = [
                this._registerCommunicators(),
                this._registerThemes(),
                this._registerAnimations(),
                this._registerLanguages()
            ];

            $.when.apply($, registerDeferredList).done(utility.hitch(this, function () {
                $.when(this._setupLayout()).done(utility.hitch(this, this._setupEvents));
            }));
        },

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

        // =================================================================================================================================================
        // Register functions
        // =================================================================================================================================================

        _registerCommunicators: function () {
            // summary:
            //      Setup application communicator(s)
            // tags:
            //      private

            communicatorController.registerCommunicator(communicator);
        },

        _registerThemes: function () {
            // summary:
            //      Setup application theme(s)
            // tags:
            //      private

            if (!this._config || !this._config.theme || !utility.isValidArray(this._config.theme.items)) {
                return;
            }

            appSettings.registerSetting({
                settingKey: 'theme',
                mode: 'clean',
                registerValueList: this._config.theme.items
            });
        },

        _registerAnimations: function () {
            // summary:
            //      Setup application animation(s)
            // tags:
            //      private

            var $deferred = $.Deferred();
            if (!this._config || !this._config.animation || !utility.isValidArray(this._config.animation.items)) {
                $deferred.resolve();

                return $deferred.promise();
            }

            var animations = this._config.animation.items,
                totalItems = animations.length,
                item;

            // register Animation (provided by buildin and submodule)
            while (totalItems--) {
                item = animations[totalItems];

                animationController.registerAnimation(require('components/Svg/Animation/Effect/' + item));

                if (totalItems === 0) {
                    $deferred.resolve();
                }
            }

            return $deferred.promise();
        },

        _registerLanguages: function () {
            // summary:
            //      Register enabled language(s)
            // tags:
            //      private

            if (!this._config || !this._config.language || !utility.isValidArray(this._config.language.items)) {
                return;
            }

            appSettings.registerSetting({
                settingKey: 'languageId',
                mode: 'clean',
                registerValueList: this._config.language.items
            });
        },

        // =================================================================================================================================================
        // Layout functions
        // =================================================================================================================================================

        _setupLayout: function () {
            // summary:
            //      Initialize default layout settings for the component
            // tags:
            //      private

            var $deferred = $.Deferred(),
                deferredList = [
                    this._setupTheme(),
                    this._resize()
                ];

            $.when.apply($, deferredList).done(utility.hitch(this, function () {
                $.when(this._getLocalizeResources()).done(utility.hitch(this, function (/*Object*/localizeResources) {
                    this._$dashboard = $('#wrapper').LiveMonitorDashboard({
                        resources: localizeResources || {},
                        placeHolder: '#epi-addons-liveMonitor'
                    });

                    $deferred.resolve();
                }));
            }));

            return $deferred.promise();
        },

        _setupTheme: function () {
            // summary:
            //      Setup theme for the application
            // tags:
            //      private

            var $head = $('head'),
                $body = $('body'),
                $lastHeadLink = $head.find('link[rel="stylesheet"]:last'),
                themesRoot = appSettings.getSetting('themesRootPath'),
                themeName = appSettings.getSetting('theme'),
                themeLink = utility.buildPath([
                    '<link type="text/css" rel="stylesheet" href="' + themesRoot,
                    themeName,
                    'Styles.css" />'
                ]);

            ($lastHeadLink && $lastHeadLink.length) ? $lastHeadLink.after(themeLink) : $head.append(themeLink);

            $body.addClass(appSettings.getSetting('theme'));
        },

        _resize: function () {
            // summary:
            //      Resize the layout of the dashboard in order to get full height and width of the container
            // tags:
            //      private

            var $body = $('body'),
                $globalNavigationContainer = $('.epi-globalNavigationContainer'),
                $liveMonitorContainer = $('#epi-addons-liveMonitor');

            $liveMonitorContainer.height($body.height() - $globalNavigationContainer.height());

            this._layout();
        },

        _layout: function () {
            // summary:
            //      Layout the dashboard component and its children
            // tags:
            //      private

            if (!this._$dashboard) {
                return;
            }

            var dashboard = utility.getInstance(this._$dashboard);
            if (!dashboard || !$.isFunction(dashboard.layout)) {
                return;
            }

            dashboard.layout();
        },

        _getLocalizeResources: function () {
            // summary:
            //      Get the localize resources of the application
            // tags:
            //      private

            var $deferred = $.Deferred();
            if (!this._config || !this._config.jsonLanguageResourcesPath) {
                return;
            }

            return $.getJSON(this._config.jsonLanguageResourcesPath);
        },

        // =================================================================================================================================================
        // Events functions
        // =================================================================================================================================================

        _setupEvents: function () {
            // summary:
            //      Setup events for the current container
            // tags:
            //      private

            $(window).on('resize', utility.hitch(this, this._resize));
            $('.epi-globalNavigationContainer').on('click', utility.hitch(this, this._resize));
        }
    };

    AppMain.init();

    return AppMain;

});