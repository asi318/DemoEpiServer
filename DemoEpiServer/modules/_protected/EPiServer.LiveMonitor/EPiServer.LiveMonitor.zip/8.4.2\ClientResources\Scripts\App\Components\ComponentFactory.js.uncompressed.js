﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'components/BaseComponent'
],

function (
// libs
    $,
// live monitor
    utility,

    baseComponent
) {

    // shim
    if (!$.isFunction(Object.create)) {
        Object.create = function (o) {
            function F() { };
            F.prototype = o;
            return new F();
        };
    };

    // =================================================================================================================================================
    // ComponentFactory class
    // =================================================================================================================================================

    var ComponentFactory = {

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        create: function (/*Object*/component, /*String*/componentName, /*Object*/componentDefinitions, /*Object*/componentOptions) {
            // summary:
            //      A really lightweight component wrapper around the constructor, 
            //      preventing against multiple instantiations
            // component: [Object]
            //      The given component object
            // componentName: [String]
            //      The given component name
            // componentDefinitions: [Object]
            //      The given component definitions that will be used to decorates the default definitions
            // componentOptions: [Object]
            //      The given component options that will be used to decorates the default options
            // tags:
            //      protected

            if (componentOptions && utility.getURLParameter(componentOptions.enableParam) == 'false') {
                return;
            }

            if (!component.length) {
                return;
            }

            var concreteDefinitions = $.extend(true, {}, baseComponent, componentDefinitions);

            return component.each(function () {
                // Plugin is not instanciated. Create it (requires an object or null as arguments)
                if (!$.data(this, componentName)) {
                    if (typeof componentOptions === 'object' || !componentOptions) {
                        // Create an instance of our concrete component
                        var instance = Object.create(concreteDefinitions);
                        instance.setup(this, componentOptions, componentName);

                        $.data(this, componentName, instance);
                    } else {
                        $.error('Plugin jQuery.' + componentName + '  has not yet been instanciated.');
                    }
                } else if (typeof componentOptions === 'string') {
                    // Not allowed to call private function of the given instance
                    if (componentOptions[0] === '_') {
                        $.error('Plugin jQuery.' + componentName + ' : method ' + componentOptions + ' is private.');
                        return;
                    }

                    // Plugin is instanciated, get it
                    var controller = $.data(this, componentName);
                    if (controller[componentOptions]) {
                        controller[componentOptions](Array.prototype.slice.call(input, 1));
                    } else {
                        $.error('Plugin jQuery.' + componentName + ' has no method ' + componentOptions);
                    }
                } else {
                    $.error('Plugin jQuery.' + componentName + ' has already been instanciated.');
                }
            });
        }

    };

    return ComponentFactory;

});