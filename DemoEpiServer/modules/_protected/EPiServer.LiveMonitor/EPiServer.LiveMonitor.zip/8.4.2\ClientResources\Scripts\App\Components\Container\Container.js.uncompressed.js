﻿define([
// libs
    'jquery',
// live monitor
    'components/ComponentFactory',
// resources
    'text!components/Container/Templates/Container.html'
],

function (
// libs
    $,
// live monitor
    componentFactory,
// resources
    templateString
) {

    // =================================================================================================================================================
    // 'LiveMonitorContainer' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Container/LiveMonitorContainer'
    // summary:
    //      The jQuery plugin component for the container
    // description:
    //      use:
    //          $(target).LiveMonitorContainer(options);
    //      options:
    //          resources [Object]
    //          templateString [String]
    //          baseClasses [String]
    //          children [Array]
    // tags:
    //      public

    // Create the defaults once
    var pluginName = 'LiveMonitorContainer',
        pluginOptions = {
            templateString: templateString,
            baseClasses: 'livemonitor-container',
            children: []
        },
        pluginDefinitions = {

            // =================================================================================================================================================
            // Overrided functions
            // =================================================================================================================================================

            _onAddChild: function (/*Object*/child) {
                // summary:
                //      Place to decorates the given child element
                // child: [Object]
                //      The given child element that want to decorates
                // tags:
                //      protected, extensions

                child && child.wrap('<li></li>');
            }

            // =================================================================================================================================================
            // Private functions
            // =================================================================================================================================================

        };

    // A really lightweight plugin wrapper around the constructor, 
    //  preventing against multiple instantiations
    $.fn[pluginName] = function (/*Object*/options) {
        // summary:
        //      Create a new jQuery plugin from the given settings
        // options: [Object]
        //      The given settings that wanted to decorates the default settings of the current component
        // returns: [Object]
        //      The jQuery plugin object
        // tags:
        //      protected

        // Decorates the default settings by the given settings
        $.extend(true, pluginOptions, options);

        // Create and then return a new jQuery plugin object
        return componentFactory.create(this, pluginName, pluginDefinitions, pluginOptions);
    };

});