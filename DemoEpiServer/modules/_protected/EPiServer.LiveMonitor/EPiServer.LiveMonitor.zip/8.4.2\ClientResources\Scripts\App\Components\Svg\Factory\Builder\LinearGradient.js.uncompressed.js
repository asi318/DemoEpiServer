﻿define([
// libs
    'jquery',
// live monitor
    'utility'
],

function (
// libs
    $,
// live monitor
    utility
) {

    // =================================================================================================================================================
    // 'LinearGradientElementBuilder' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Svg/Factory/Builder/LinearGradientElementBuilder'
    // summary:
    //      The element builder class for 'linearGradient' SVG object
    // description:
    //      Create the 'LINEARGRADIENT' SVG element
    // tags:
    //      public

    var LinearGradientElementBuilder = {

        elementName: 'linearGradient',

        create: function (/*Object*/linearGradientSettings, /*Array*/container, /*Function?*/recursiveCreate) {
            // summary:
            //      Create and then append a horizontal linear gradient SVG definition
            //      Linear gradients can be defined as horizontal, vertical or angular gradients:
            //          Vertical gradients are created when x1 and x2 are equal and y1 and y2 differ
            //          Angular gradients are created when x1 and x2 differ and y1 and y2 differ
            // linearGradientSettings: [Object]
            //      Settings for horizontal linear gradient:
            //          linearGradient: {
            //              'id': 'horizontalLinearGradient',
            //              'class': 'livemonitor-lineargradient horizontal',
            //              x1: '0%',
            //              y1: '0%',
            //              x2: '100%',
            //              y2: '0%',
            //              stop: [
            //                  { offset: '0%' },
            //                  { offset: '100%' }
            //              ]
            //          }
            //      Settings for vertical linear gradient:
            //          linearGradient: {
            //              'id': 'verticalLinearGradient',
            //              'class': 'livemonitor-lineargradient vertical',
            //              x1: '0%',
            //              y1: '0%',
            //              x2: '0%',
            //              y2: '100%',
            //              stop: [
            //                  { offset: '0%' },
            //                  { offset: '100%' }
            //              ]
            //          }
            // container: [Array]
            //      The given container
            // recursiveCreate: [Function?]
            //      Indicated that should or should not create children recursively
            // tags:
            //      public

            if (!linearGradientSettings) {
                return;
            }

            var linearGradientList = container.selectAll(this.elementName)
                        .data(utility.getItemCollection(linearGradientSettings))
                            .enter()
                    .append(this.elementName)
                        .attr('id', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.elementId;
                        })
                        .attr('class', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.classes;
                        })
                        .attr('x1', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.x1;
                        })
                        .attr('y1', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.y1;
                        })
                        .attr('x2', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.x2;
                        })
                        .attr('y2', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.y2;
                        });

            $.isFunction(recursiveCreate) && recursiveCreate(linearGradientSettings, /*container*/linearGradientList);
        }

    };

    return LinearGradientElementBuilder;

});