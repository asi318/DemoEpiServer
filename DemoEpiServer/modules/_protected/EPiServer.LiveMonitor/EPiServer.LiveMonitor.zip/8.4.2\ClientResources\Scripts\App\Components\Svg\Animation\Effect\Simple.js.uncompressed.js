﻿/*
THIS IS SAMPLE for creating animation of visitor in Dashboard
*/

define([
// libs
    'jquery',
    'd3'
],

function (
// libs
    $,
    dataVisualizer
) {

    // =================================================================================================================================================
    // 'SimpleAnimation' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Svg/Animation/Effect/SimpleAnimation'
    // summary:
    //      The simple animation class
    // description:
    //      This is an animation to creating simple effect for a visitor in Dashboard
    //      Public functions:
    //          apply(/*Object*/marker, /*Integer*/delay)
    // tags:
    //      public

    var SimpleAnimation = {

        // key: [String] public
        //      The unique key that used to register to the controller
        //      The controller used this key to identifies each registered animation animation
        key: 'Simple',

        // name: [String] public
        //      The animation animation name that used to register to the controller
        //      The application used this name to display
        name: 'Simple',

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        apply: function (/*Object*/marker, /*Integer*/delay) {
            // summary:
            //      Create an animation pattern
            // marker: [Object]
            //      The given object that wanted to bind the indicated animation
            // delay: [Integer]
            //      The given delay time (so we can tweak that all objects does not start at the same moment)
            // tags:
            //      public

        }

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

    };

    return SimpleAnimation;

});