﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'data/TransferRepository'
],

function (
// libs
    $,
// live monitor
    utility,

    transferRepository
) {

    // =================================================================================================================================================
    // 'StatisticRepository' class information
    // =================================================================================================================================================
    // module:
    //      'App/Data/StatisticRepository'
    // summary:
    //      The repository for application statistic
    // description:
    //      Public functions:
    //          getHitsPerHour(/*Boolean*/autoCalculate)
    //          getClientsPerHour(/*Boolean*/autoCalculate)
    //          saveOnlineVisitorList(/*Array*/onlineVisitorList)
    // tags:
    //      public

    var StatisticRepository = {

        // _dataKey: [String] private
        //      The statistics data key that used to get/set the statistics data from/to
        _dataKey: 'statisticsData',

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        getHitsPerHour: function (/*Boolean*/autoCalculate) {
            // summary:
            //      Get total hits per hour
            // autoCalculate: [Boolean]
            //      Flag indicates that should or should not auto calculate hits per hour
            // returns: [Integer]
            //      The total hits per hour
            // tags:
            //      public

            var data = this.getData();
            if (!data) {
                return 0;
            }

            var hitsPerHour = (data && data.hitsPerHour) || 0,
                previousVisitsData = data.previousVisitsData,
                currentVisitsData = data.currentVisitsData;
            if (!autoCalculate || !$.isArray(previousVisitsData) || !$.isArray(currentVisitsData)) {
                return hitsPerHour;
            }

            var totalNewItems = 0,
                totalItems = currentVisitsData.length,
                item;

            while (totalItems--) {
                item = currentVisitsData[totalItems];
                if (!item) {
                    continue;
                }

                if ($.inArray(item, previousVisitsData) === -1) {
                    totalNewItems++;
                }
            }

            return hitsPerHour + previousVisitsData.length + totalNewItems;
        },

        getClientsPerHour: function (/*Boolean*/autoCalculate) {
            // summary:
            //      Get total clients per hour
            // autoCalculate: [Boolean]
            //      Flag indicates that should or should not auto calculate clients per hour
            // returns: [Integer]
            //      The total clients per hour
            // tags:
            //      public

            var data = this.getData();
            if (!data) {
                return 0;
            }

            var clientsPerHour = (data && data.clientsPerHour) || 0,
                visitsData = data.visitsData;
            if (!autoCalculate) {
                return clientsPerHour;
            }

            if (!utility.isValidArray(visitsData)) {
                visitsData = [];
            }

            var previousVisitsData = data.previousVisitsData;
            if (utility.isValidArray(previousVisitsData)) {
                visitsData = visitsData.concat(previousVisitsData);
            }

            var currentVisitsData = data.currentVisitsData;
            if (utility.isValidArray(currentVisitsData)) {
                visitsData = visitsData.concat(currentVisitsData);
            }

            var totalItems = visitsData.length,
                item,
                itemKey,
                clients = [];

            while (totalItems--) {
                item = visitsData[totalItems];
                if (!item) {
                    continue;
                }

                // Stored data format:
                //  ex.:
                //      '8a37e8eb-039e-4e9d-8563-7a273d9be270|36|2014-03-27T08:43:47.2805264+07:00'
                //  Fields order:
                //      {visitId}|{visitContentId}|{visitDatetime}
                itemKey = item.split('|')[0];
                if ($.inArray(itemKey, clients) === -1) {
                    clients.unshift(itemKey);
                }
            }

            return clients.length;
        },

        saveOnlineVisitorList: function (/*Array*/onlineVisitorList) {
            // summary:
            //      Save the given collection of the online visitor object
            // onlineVisitorList: [Array]
            //      The given collection of the online visitor object
            // tags:
            //      public

            var lightOnlineVisitorList = this._getLightOnlineVisitorList(onlineVisitorList);
            if (!utility.isValidArray(lightOnlineVisitorList)) {
                return;
            }

            this.saveData(this._mergeStatisticsData(lightOnlineVisitorList));
        },

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

        // =================================================================================================================================================
        // Process statistics data functions
        // =================================================================================================================================================

        _mergeStatisticsData: function (/*Array*/lightOnlineVisitorList) {
            // summary:
            //      Merge two given data sources
            // lightOnlineVisitorList: [Array]
            //      The given collection of the light online visitor object
            // tags:
            //      private

            var existingData = this.getData(),
                previousVisitsData = utility.isValidArray(existingData.previousVisitsData) ? existingData.previousVisitsData : [],
                currentVisitsData = existingData.currentVisitsData;

            if (utility.isValidArray(currentVisitsData)) {
                var totalItems = currentVisitsData.length,
                    item;

                while (totalItems--) {
                    item = currentVisitsData[totalItems];
                    if (!item) {
                        continue;
                    }

                    if ($.inArray(item, previousVisitsData) === -1) {
                        previousVisitsData.push(item);
                    }
                }
            }

            return $.extend(true, {}, existingData, {
                previousVisitsData: previousVisitsData,
                currentVisitsData: lightOnlineVisitorList
            });
        }

    };

    var statisticRepository = $.extend(true, {}, transferRepository, StatisticRepository);
    statisticRepository.init();

    return statisticRepository;

});