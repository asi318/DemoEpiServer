﻿define([
// libs
    'jquery',
    'd3',
// live monitor
    'utility',

    'components/Svg/Layout/BaseSvgLayout',

    'components/Svg/Factory/MarkupController'
],

function (
// libs
    $,
    dataVisualizer,
// live monitor
    utility,

    baseSvgLayout,

    markupController
) {

    // =================================================================================================================================================
    // Component information
    // =================================================================================================================================================
    //
    // module:
    //      Components/Svg/Layout/PointerEventsLayout
    // summary:
    //      
    // description:
    //      
    // tags:
    //      public

    var PointerEventsLayout = {

        // Default settings for the component
        settings: {
            // Default place holder for the current svg element
            placeHolder: 'body'
        },

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        create: function (/*Object*/settings) {
            // summary:
            //      Create a new instance of the component
            // settings: [Object]
            //      The new settings that wanted to decorates the default settings of the given component
            // returns: [Object]
            //      An instance of the component
            // tags:
            //      public

            $.extend(true, this.settings, settings);

            this._createSvg();

            return this;
        },

        bindData: function (/*Object*/pointerEventsLayoutData) {
            // summary:
            //      Binding the given data to the component and its children
            // pointerEventsLayoutData: [Object]
            //      The given pointer events layout data object
            //          hierarchicalMappingData: [Array]
            //              The given data set that wanted to bind to the current component
            //          templateList: [Array]
            //              The given template list
            // tags:
            //      public

            var hierarchicalMappingData = pointerEventsLayoutData.hierarchicalMappingData,
                templateString = pointerEventsLayoutData.templateString;

            this._transparentBallTemplateList = templateString.transparentBalls;

            this._updateNodesData(hierarchicalMappingData);
            this._shouldUpdate(hierarchicalMappingData) && this._setupNodesPosition();
        },

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

        _createSvg: function () {
            // summary:
            //      Create the SVG element
            // tags:
            //      private

            this._svg = this._svg || dataVisualizer.select(this.settings.placeHolder).append('svg').attr('class', 'livemonitor-pointerEventsLayout');
        },

        _updateNodesData: function (/*Array*/nodeDataList) {
            // summary:
            //      Update the node collection from the given data
            // nodeDataList: [Array]
            //      The given collection of node object
            // tags:
            //      private

            // DATA JOIN
            // Join new data with old elements, if any.
            this._groupList = this._svg.selectAll('.pointer')
                .data(nodeDataList, function (/*Object*/d) {
                    // d: [Object]
                    //      The given datum object

                    return d.contentId;
                });

            // UPDATE
            // Update old elements as needed.
            this._groupList.attr('class', 'pointer updated');

            // ENTER
            // Create new elements as needed.
            var newGroupList = this._groupList.enter().append('g').attr('class', 'pointer enter');
            this._setupNodesLayout(newGroupList[0]);

            // EXIT
            // Remove old elements as needed.
            this._groupList.exit().remove();
        },

        _setupNodesPosition: function () {
            // summary:
            //      Setup position for the given collection of node object
            // tags:
            //      private

            this._groupList.attr('transform', function (/*Object*/d) {
                // d: [Object]
                //      The given datum object

                return 'translate(' + d.x + ',' + d.y + ')';
            });
        },

        _setupNodesLayout: function (/*Array*/newGroupList) {
            // summary:
            //      Setup layout for the given nodes
            // newGroupList: [Array]
            //      The given collection of the node container object
            // tags:
            //      private

            var totalItems = newGroupList.length,
                container,
                containerNode,
                itemData;

            while (totalItems--) {
                container = dataVisualizer.select(newGroupList[totalItems]);
                containerNode = container.node();

                itemData = containerNode && container.datum();
                if (!itemData) {
                    continue;
                }

                containerNode.appendChild(this._getTemplateContent(this._transparentBallTemplateList[totalItems]));

                this._setupHoverState(/*senders*/[container.select('circle')]);
            }
        },

        _setupHoverState: function (/*Array*/senders) {
            // summary:
            //      Applies HOVER state for the given node
            // senders: [Array]
            //      The sender node that wanted to applies hover state
            // tags:
            //      private

            var totalItems = senders.length,
                sender,
                $placeHolder = $(this.settings.placeHolder);

            while (totalItems--) {
                sender = senders[totalItems];

                sender.on('mouseenter', utility.hitch(this, function () {
                    // summary:
                    //      The mouseenter event differs from mouseover in the way it handles event bubbling.
                    //      If mouseover were used in this example, then when the mouse pointer moved over the Inner element, the handler would be triggered.
                    //      This is usually undesirable behavior.
                    //      The mouseenter event, on the other hand, only triggers its handler when the mouse enters the element it is bound to, not a descendant.
                    //      So in this example, the handler is triggered when the mouse enters the Outer element, but not the Inner element.

                    this._stopPropagation();

                    $placeHolder.trigger('toggleActionLayer', [true]);
                }));
            }
        }
    };

    return $.extend(true, {}, baseSvgLayout, PointerEventsLayout);

});