﻿define([
// libs
    'jquery',
// live monitor
    'components/Svg/Factory/Template/BaseTemplate'
],

function (
// libs
    $,
// live monitor
    baseTemplate
) {

    // =================================================================================================================================================
    // 'MediumBallTemplate' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Svg/Factory/Template/MediumBallTemplate'
    // summary:
    //      Provides medium ball content markup template in SVG format
    // description:
    //      Public functions:
    //          load(/*String?*/text)
    //              Load SVG in JSON format
    //          loadExternal()
    //              Load SVG in raw format (SVG markup string)
    // tags:
    //      public

    var MediumBallTemplate = {

        // key: [String] public
        //      The unique key that used to register to the controller
        //      The controller used this key to identifies each registered template
        key: 'MediumBall',

        // name: [String] public
        //      The template name that used to register to the controller
        //      The application used this name to display
        name: 'Medium Ball Template',

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        load: function (/*String?*/text) {
            // summary:
            //      Get predefined markup settings for a medium ball SVG object
            // text: [String?]
            //      The given text that wanted to bind to the 'text' SVG tag
            // returns: [Object]
            //      The JSON markup settings for a medium ball SVG object
            // tags:
            //      public

            return {
                svg: {
                    height: 30,
                    width: 30,
                    g: {
                        classes: 'livemonitor-ball medium',
                        circle: {
                            cx: 15,
                            cy: 15,
                            r: 15,
                            fill: 'url(#livemonitor-verticalLinearGradient)'
                        },
                        ellipse: {
                            cx: 15,
                            cy: 10,
                            rx: 11,
                            ry: 8
                        },
                        text: {
                            classes: 'number',
                            x: 10,
                            y: 13,
                            value: text
                        }
                    }
                }
            };
        }

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

    };

    return $.extend(true, {}, baseTemplate, MediumBallTemplate);

});