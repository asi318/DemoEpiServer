﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'components/ComponentFactory',

    'components/Tree/HierarchicalForceLayoutWrapper',
    'components/Tree/HighwayLayoutWrapper',
    'components/Tree/MultiFociLayoutWrapper',
    'components/Tree/PointerEventsLayoutWrapper',

    'data/HierarchicalMappingRepository'
],

function (
// libs
    $,
// live monitor
    utility,

    componentFactory,

    hierarchicalForceLayoutWrapper,
    highwayLayoutWrapper,
    multiFociLayoutWrapper,
    pointerEventsLayoutWrapper,

    hierarchicalMappingRepository
) {

    // =================================================================================================================================================
    // 'LiveMonitorMultiLayerContainer' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Tree/LiveMonitorMultiLayerContainer'
    // summary:
    //      The jQuery plugin for the multi-layer component
    // description:
    //      use:
    //          $(target).LiveMonitorMultiLayerContainer(options);
    //      options:
    //          resources [Object]
    //          templateString [String]
    //          baseClasses [String]
    //          containerWidth [Integer]
    //          containerHeight [Integer]
    //          sender [String]
    //          senderCallback [String]
    // tags:
    //      public

    // Create the defaults once
    var pluginName = 'LiveMonitorMultiLayerContainer',
        pluginOptions = {
            templateString: '<div class="item-list"></div>',
            baseClasses: 'livemonitor-multiLayerContainer',
            // Default width for the children's layout
            containerWidth: 800,
            // Default height for the children's layout
            containerHeight: 600,
            sender: 'trace',
            senderCallback: 'getVisitorsData'
        },
        pluginDefinitions = {

            // =================================================================================================================================================
            // Overrided functions
            // =================================================================================================================================================

            _postInit: function () {
                // summary:
                //      Post-initialize settings for the component
                // tags:
                //      protected, extension

                this._repository = hierarchicalMappingRepository;

                this._setupLayout();
                this._setupEvents();
            },

            // =================================================================================================================================================
            // Public callback functions
            // =================================================================================================================================================

            onReceiveCompleted: function (/*Object*/visitorsData) {
                // summary:
                //      Fired after client requested to server and then server responsed
                // visitorsData: [Object]
                //      The given visitors data that returned from server side
                //      It included following information:
                //          onlineVisitors: [Array]
                //              The given collection of online visitor object
                //          historyVisitors: [Array]
                //              The given collection of history visitor object
                // tags:
                //      public, extensions

                if (!visitorsData) {
                    return;
                }

                visitorsData = utility.getJSONObject(visitorsData);

                this._bindData(utility.cloneObject(visitorsData.onlineVisitors));

                this.triggerContextEvent('updateVisitorsData', visitorsData);
            },

            bindData: function (/*Object*/onlineVisitorsData) {
                // summary:
                //      Fired when had any change in server side
                // onlineVisitorsData: [Object]
                //      The given visitors data that will be used to bind to the multi foci layout control
                // tags:
                //      public, extensions

                this._bindData(onlineVisitorsData);
            },

            // =================================================================================================================================================
            // Private events
            // =================================================================================================================================================

            _onHierarchicalLayoutProcessing: function (/*Event*/evt) {
                // summary:
                //      Fired when the hierarchical force layout finished it layout process
                // evt: [Event]
                //      The given event
                // tags:
                //      private

                utility.toggleVisibility([this._highwayLayoutWrapper], false);
            },

            _onHierarchicalContentSelected: function (/*Event*/evt, /*Object*/selectedHierarchicalContent) {
                // summary:
                //      Fired when a hierarchical content is selected
                // evt: [Event]
                //      The given event
                // selectedHierarchicalContent: [Object]
                //      The given hierarchical content selection object
                // tags:
                //      private

                this._selectedHierarchicalContent = selectedHierarchicalContent;
            },

            _onHierarchicalLayoutFinished: function (/*Event*/evt, /*Array*/hierarchicalMappingData, /*Array*/unmappedData) {
                // summary:
                //      Fired when the hierarchical force layout finished it layout process
                // evt: [Event]
                //      The given event
                // hierarchicalMappingData: [Array]
                //      The given mapping data of the hierarchical force layout
                // unmappedData: [Array]
                //      The given un-mapped data of the hierarchical force layout
                // tags:
                //      private

                utility.toggleVisibility([this._highwayLayoutWrapper], true);

                this._hierarchicalMappingData = hierarchicalMappingData;

                this._repository.saveMappingData(hierarchicalMappingData);

                this._hierarchicalForceLayoutWrapper = utility.getInstance(this._$hierarchicalForceLayoutWrapper);
                if (utility.isValidArray(unmappedData) && this._hierarchicalForceLayoutWrapper && $.isFunction(this._hierarchicalForceLayoutWrapper.expandContents)) {
                    unmappedData.sort(this._repository.sortByAncestorsLevel);
                    this._hierarchicalForceLayoutWrapper.expandContents(hierarchicalMappingData, unmappedData);
                }

                !utility.isValidArray(this._onlineVisitorsData)
                    ? this._requestVisitorsData()
                    : this._bindData(this._onlineVisitorsData);
            },

            _onToggleActionLayer: function (/*Event*/evt, /*Boolean*/enable) {
                // summary:
                //      Toggle the action layer
                // evt: [Event]
                //      The given event
                // enable: [Boolean]
                //      Enable/Disable the action layer
                // tags:
                //      private

                this._$hierarchicalForceLayoutWrapper.toggleClass('top-layer', enable || false);
            },

            // =================================================================================================================================================
            // Private functions
            // =================================================================================================================================================

            _setupLayout: function () {
                // summary:
                //      Setup layout for the current container
                // tags:
                //      private

                this._$hierarchicalForceLayoutWrapper = $('<div></div>').LiveMonitorHierarchicalForceLayoutWrapper({
                    containerHeight: this.options.containerHeight,
                    containerWidth: this.options.containerWidth
                });

                this._$multiFociLayoutWrapper = $('<div></div>').LiveMonitorMultiFociLayoutWrapper();
                this._$highwayLayoutWrapper = $('<div></div>').LiveMonitorHighwayLayoutWrapper();
                this._$pointerEventsLayoutWrapper = $('<div></div>').LiveMonitorPointerEventsLayoutWrapper();

                if (!utility.isValidArray(this.options.children)) {
                    this.options.children = [
                        this._$hierarchicalForceLayoutWrapper,
                        this._$multiFociLayoutWrapper,
                        this._$highwayLayoutWrapper,
                        this._$pointerEventsLayoutWrapper
                    ];
                } else {
                    // Removes 0 element from index 0, and then inserts 4 new elements
                    this.options.children = this.options.children.splice(
                        /*index*/0,
                        /*howMany*/0,
                        this._$hierarchicalForceLayoutWrapper,
                        this._$multiFociLayoutWrapper,
                        this._$highwayLayoutWrapper,
                        this._$pointerEventsLayoutWrapper);
                }
            },

            _setupEvents: function () {
                // summary:
                //      Setup events for the current container and its children
                // tags:
                //      private

                if (!this._$hierarchicalForceLayoutWrapper || !this._$pointerEventsLayoutWrapper) {
                    return;
                }

                this._setupContextEvents();
                this._setupHierarchicalForceLayoutWrapperEvents();
                this._setupPointerEventsLayoutWrapperEvents();
            },

            _setupContextEvents: function () {
                // summary:
                //      Setup events for the the application context
                // tags:
                //      private

                this.bindContextEvent('renderHighways', utility.hitch(this, this._bindHighwayData));
            },

            _setupHierarchicalForceLayoutWrapperEvents: function () {
                // summary:
                //      Setup events for the 'HierarchicalForceLayoutWrapper' component
                // tags:
                //      private

                this._$hierarchicalForceLayoutWrapper.bind('hierarchicalLayoutProcessing', utility.hitch(this, this._onHierarchicalLayoutProcessing));
                this._$hierarchicalForceLayoutWrapper.bind('hierarchicalContentSelected', utility.hitch(this, this._onHierarchicalContentSelected));
                this._$hierarchicalForceLayoutWrapper.bind('hierarchicalLayoutFinished', utility.hitch(this, this._onHierarchicalLayoutFinished));

                this._$hierarchicalForceLayoutWrapper.bind('toggleActionLayer', utility.hitch(this, this._onToggleActionLayer));

            },

            _setupPointerEventsLayoutWrapperEvents: function () {
                // summary:
                //      Setup events for the 'PointerEventsLayoutWrapper' component
                // tags:
                //      private

                this._$pointerEventsLayoutWrapper.bind('toggleActionLayer', utility.hitch(this, this._onToggleActionLayer));
            },

            _bindData: function (/*Array*/onlineVisitorsData) {
                // summary:
                //      Fired when had any change in server side
                // onlineVisitorsData: [Array]
                //      The given visitors data that will be used to bind to the multi foci layout control
                // tags:
                //      private

                this._onlineVisitorsData = onlineVisitorsData;

                // Data binding for the 'MultiFociLayoutWrapper' object
                this._multiFociLayoutWrapper = utility.getInstance(this._$multiFociLayoutWrapper);
                (this._multiFociLayoutWrapper && onlineVisitorsData && this._hierarchicalMappingData)
                    && this._multiFociLayoutWrapper.bindData(utility.cloneObject(this._hierarchicalMappingData), utility.cloneObject(onlineVisitorsData));

                // Data binding for the 'HighwayLayoutWrapper' object
                this._bindHighwayData();

                // Data binding for the 'PointerEventsLayoutWrapper' object
                this._pointerEventsLayoutWrapper = utility.getInstance(this._$pointerEventsLayoutWrapper);
                (this._pointerEventsLayoutWrapper && this._hierarchicalMappingData)
                    && this._pointerEventsLayoutWrapper.bindData(utility.cloneObject(this._hierarchicalMappingData));
            },

            _bindHighwayData: function () {
                // summary:
                //      Bind data for the 'HighwayLayoutWrapper'
                // tags:
                //      private

                this._highwayLayoutWrapper = utility.getInstance(this._$highwayLayoutWrapper);
                (this._highwayLayoutWrapper && this._hierarchicalMappingData)
                    && this._highwayLayoutWrapper.bindData(utility.cloneObject(this._hierarchicalMappingData), this._selectedHierarchicalContent);
            },

            // =================================================================================================================================================
            // Request data functions
            // =================================================================================================================================================

            _requestVisitorsData: function () {
                // summary:
                //      Send request to server ('getVisitorsData') in order to get hierarchical data
                // tags:
                //      private

                // Send a request to 'getVisitorsData' proxy function
                //  with following parameters:
                //      languageId: [String]
                //          The given language identification
                $.isFunction(this.send) && this.send();
            }
        };

    // A really lightweight plugin this._$wrapper around the constructor, 
    //  preventing against multiple instantiations
    $.fn[pluginName] = function (/*Object*/options) {
        // summary:
        //      Create a new jQuery plugin from the given settings
        // options: [Object]
        //      The given settings that wanted to decorates the default settings of the current component
        // returns: [Object]
        //      The jQuery plugin object
        // tags:
        //      protected

        // Decorates the default settings by the given settings
        $.extend(true, pluginOptions, options);

        // Create and then return a new jQuery plugin object
        return componentFactory.create(this, pluginName, pluginDefinitions, pluginOptions);
    };

});