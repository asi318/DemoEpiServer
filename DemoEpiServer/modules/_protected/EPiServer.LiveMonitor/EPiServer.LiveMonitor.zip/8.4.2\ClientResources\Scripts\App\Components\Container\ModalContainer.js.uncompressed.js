﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'components/ComponentFactory',
// resources
    'text!components/Container/Templates/ModalContainer.html'
],

function (
// libs
    $,
// live monitor
    utility,

    componentFactory,
// resources
    templateString
) {

    // =================================================================================================================================================
    // 'LiveMonitorModalContainer' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Container/LiveMonitorModalContainer'
    // summary:
    //      The jQuery plugin component for the modal container
    // description:
    //      use:
    //          $(target).LiveMonitorModalContainer(options);
    //      options:
    //          resources [Object]
    //          templateString [String]
    //          baseClasses [String]
    //          children [Array]
    // tags:
    //      public

    // Create the defaults once
    var pluginName = 'LiveMonitorModalContainer',
        pluginOptions = {
            templateString: templateString,
            baseClasses: 'livemonitor-container',
            showReset: false,
            showSave: false,
            showClose: false,
            children: []
        },
        pluginDefinitions = {

            // =================================================================================================================================================
            // Overrided functions
            // =================================================================================================================================================

            _postInit: function () {
                // summary:
                //      Post-initialize settings for the component
                // tags:
                //      protected, extension

                this._setupLayout();
                this._setupEvents();
            },

            _onGetListSelector: function (/*String*/defaultSelector) {
                // summary:
                //      Place to modify the selector of the list container
                // defaultSelector: [String]
                //      The given selector by default
                // returns: [String]
                //      The selector string
                // tags:
                //      protected, extensions

                return '.modal-dialog .modal-content .modal-body';
            },

            // =================================================================================================================================================
            // Private functions
            // =================================================================================================================================================

            _setupLayout: function () {
                // summary:
                //      Setup layout for the current container
                // tags:
                //      private

                this._$wrapper.addClass('modal fade');
                this._$wrapper.attr('tabindex', -1);
                this._$wrapper.attr('role', 'dialog');
                this._$wrapper.attr('aria-hidden', true);

                this._setupHeaderTitle();
                this._setupDefaultButtons();
            },

            _setupHeaderTitle: function () {
                // summary:
                //      Setup the modal dialog header title
                // tags:
                //      private

                var $modalTitle = this._$wrapper.find('.modal-dialog .modal-content .modal-header .modal-title'),
                    modalTitle = this._resources.headertitle;
                (modalTitle && $modalTitle) && $modalTitle.text(modalTitle);
            },

            _setupDefaultButtons: function () {
                // summary:
                //      Setup the modal dialog buttons
                // tags:
                //      private

                var closeText = this._resources.buttons.close,
                    saveText = this._resources.buttons.save,
                    resetText = this._resources.buttons.reset;

                this._$footer = this._$wrapper.find('.modal-dialog .modal-content .modal-footer');

                this._$resetButton = this._$footer.find('.reset-button');
                this._$saveButton = this._$footer.find('.save-button');
                this._$closeButton = this._$footer.find('.close-button');

                if (this._$closeButton) {
                    closeText && this._$closeButton.text(closeText);
                    this._$closeButton.css('display', this.options.showClose ? '' : 'none');
                }

                if (this._$saveButton) {
                    saveText && this._$saveButton.text(saveText);
                    this._$saveButton.css('display', this.options.showSave ? '' : 'none');
                }

                if (this._$resetButton) {
                    resetText && this._$resetButton.text(resetText);
                    this._$resetButton.css('display', this.options.showReset ? '' : 'none');
                }
            },

            _setupEvents: function () {
                // summary:
                //      Setup events for the current component
                // tags:
                //      private

                this._$resetButton.on('click', utility.hitch(this, function () {
                    this.triggerContextEvent('modalDialogResetting');
                }));

                this._$saveButton.on('click', utility.hitch(this, function () {
                    this.triggerContextEvent('modalDialogSaving');
                }));

                this._$wrapper.on('hidden.bs.modal', utility.hitch(this, function () {
                    this.triggerContextEvent('modalDialogClosing');
                }));
            }

        };

    // A really lightweight plugin wrapper around the constructor, 
    //  preventing against multiple instantiations
    $.fn[pluginName] = function (/*Object*/options) {
        // summary:
        //      Create a new jQuery plugin from the given settings
        // options: [Object]
        //      The given settings that wanted to decorates the default settings of the current component
        // returns: [Object]
        //      The jQuery plugin object
        // tags:
        //      protected

        // Decorates the default settings by the given settings
        $.extend(true, pluginOptions, options);

        // Create and then return a new jQuery plugin object
        return componentFactory.create(this, pluginName, pluginDefinitions, pluginOptions);
    };

});