﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'components/ComponentFactory',

    'components/Svg/ExternalTemplatePreloader',
    'components/Svg/Layout/HighwayLayout'
],

function (
// libs
    $,
// live monitor
    utility,

    componentFactory,

    externalTemplatePreloader,
    highwayLayout
) {

    // =================================================================================================================================================
    // 'LiveMonitorHighwayLayoutWrapper' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Tree/LiveMonitorHighwayLayoutWrapper'
    // summary:
    //      The jQuery plugin for the highway (SVG) layout wrapper component
    // description:
    //      use:
    //          $(target).LiveMonitorHighwayLayoutWrapper(options);
    //      options:
    //          resources [Object]
    //          baseClasses [String]
    //          containerWidth [Integer]
    //          containerHeight [Integer]
    //          sender [String]
    //          senderCallback [String]
    // tags:
    //      public

    // Create the defaults once
    var pluginName = 'LiveMonitorHighwayLayoutWrapper',
        pluginOptions = {
            baseClasses: 'livemonitor-layer livemonitor-highwayLayoutWrapper',
            // Default container's width
            containerWidth: 800,
            // Default container's height
            containerHeight: 600,
            // Default sender object
            sender: 'trace',
            // Default sender callback function
            //  The current component will using following callback functions:
            //      getSiteHighways:
            //          Used for GLOBAL mode
            //      getSiteTransfers:
            //          Used for FROM PAGE and TO PAGE modes
            senderCallback: 'getSiteHighways'
        },
        pluginDefinitions = {

            // =================================================================================================================================================
            // Private variables
            // =================================================================================================================================================

            // _filterName: [String] private
            //      The filter function name
            _filterName: 'contentId',

            // _transparentBallTemplateKey: [String] private
            //      The key that used to get information about the transparent SVG template
            _transparentBallTemplateKey: 'TransparentBall',

            // _highwayBallTemplateKey: [String] private
            //      The key that used to get information about the highway SVG template
            _highwayBallTemplateKey: 'HighwayBall',

            // =================================================================================================================================================
            // Overrided functions
            // =================================================================================================================================================

            _postInit: function () {
                // summary:
                //      Post-initialize settings for the component
                // tags:
                //      protected, extension

                this._setupLayout();
                this._setupEvents();
            },

            // =================================================================================================================================================
            // Public callback functions
            // =================================================================================================================================================

            bindData: function (/*Object*/hierarchicalMappingData, /*Object*/selectedHierarchicalContent) {
                // summary:
                //      Binding the given data to the existing highway layout component
                // hierarchicalMappingData: [Object]
                //      The given mapping data object
                // selectedHierarchicalContent: [Object]
                //      The given selected hierarchical content
                // tags:
                //      public, extensions

                this._hierarchicalMappingData = hierarchicalMappingData;
                this._selectedHierarchicalContent = selectedHierarchicalContent;

                this._requestHighwaysData();
            },

            onReceiveCompleted: function (/*Object*/highwaysData) {
                // summary:
                //      Fired after client requested to server and then server responsed
                // highwaysData: [Object]
                //      The given highways data that will be used to bind to the highway layout control
                // tags:
                //      public, extensions

                highwaysData = utility.getJSONObject(highwaysData);

                this._highwaysData = highwaysData;
                this._bindData();
            },

            // =================================================================================================================================================
            // Private functions
            // =================================================================================================================================================

            _setupLayout: function () {
                // summary:
                //      Setup layout for the current container
                // tags:
                //      private

                this._highwayLayout = highwayLayout.create({
                    placeHolder: this.element,
                    layoutSize: {
                        height: this.options.containerHeight,
                        width: this.options.containerWidth
                    }
                });
            },

            _setupEvents: function () {
                // summary:
                //      Setup events for the current component
                // tags:
                //      private

                this.bindContextEvent('clearHighways', utility.hitch(this._highwayLayout, this._highwayLayout.clear));
            },

            _requestHighwaysData: function () {
                // summary:
                //      Request highways data from server
                // tags:
                //      private

                var highwayMode = this._getHighwayMode();
                if (!highwayMode) {
                    return;
                }

                switch (highwayMode) {
                    case 'global':
                        this.options.senderCallback = 'getSiteHighways';
                        break;
                    case 'from':
                    case 'to':
                        this.options.senderCallback = 'getSiteTransfers';
                        break;
                    default:
                        return;
                }

                // Send a request to 'getSiteHighways' or 'getSiteTransfers' proxy function
                //  with following parameters:
                //      languageId: [String]
                //          The given language identification
                $.isFunction(this.send) && this.send();
            },

            _bindData: function () {
                // summary:
                //      Data binding for the given component and its child components
                // tags:
                //      private

                var highwayMode = this._getHighwayMode();
                if (!highwayMode) {
                    return;
                }

                if (this._highwaysData && this._hierarchicalMappingData) {
                    var deferredList = [
                        this._getLinkDataList(highwayMode, this._highwaysData, this._hierarchicalMappingData, this._selectedHierarchicalContent),
                        externalTemplatePreloader.getTemplate(this._transparentBallTemplateKey),
                        externalTemplatePreloader.getTemplate(this._highwayBallTemplateKey)
                    ];

                    $.when.apply($, deferredList)
                        .done(utility.hitch(this, function (/*Array*/linkDataList, /*String*/transparentBallTemplateString, /*String*/highwayBallTemplateString) {
                            this._highwayLayout.bindData({
                                linkDataList: linkDataList,
                                hierarchicalMappingData: this._hierarchicalMappingData,
                                templateString: {
                                    transparentBall: transparentBallTemplateString,
                                    highwayBall: highwayBallTemplateString
                                }
                            });
                        }));
                }
            },

            _getHighwayMode: function () {
                // summary:
                //      Get selected highway mode
                // returns: [String]
                //      The highway mode string:
                //          'off'
                //          'from'
                //          'to'
                //          'global'
                // tags:
                //      private

                var contextSelection = this.getContextSelection(),
                    highwayMode = contextSelection && contextSelection.highwayMode;
                if (highwayMode === 'off' || !highwayMode) {
                    this._highwayLayout.clear();
                    return;
                }

                return highwayMode;
            },

            // =================================================================================================================================================
            // Data filter functions
            // =================================================================================================================================================

            _getLinkDataList: function (/*String*/highwayMode, /*Array*/highwaysData, /*Array*/hierarchicalMappingData, /*Object*/selectedHierarchicalContent) {
                // summary:
                //      Get the collection of the force layout link object from the given data
                // highwayMode: [String]
                //      The given mode to display highway data. The mode can be:
                //          'From Page'
                //          'To Page'
                //          'Global'
                // highwaysData: [Array]
                //      The given data set that wanted to bind to the current component
                // hierarchicalMappingData: [Array]
                //      The given data that used to mapping a group to a desired position (x,y)
                // selectedHierarchicalContent: [Object]
                //      The given selected hierarchical content
                // returns: [$.Deferred]
                //      The jQuery Deferred object that have:
                //          The collection of the force layout link object
                // tags:
                //      private

                switch (highwayMode) {
                    case 'from':
                        return this._getFromLinkDataList(highwaysData, hierarchicalMappingData, selectedHierarchicalContent);
                    case 'to':
                        return this._getToLinkDataList(highwaysData, hierarchicalMappingData, selectedHierarchicalContent);
                    case 'global':
                        return this._getGlobalLinkDataList(highwaysData, hierarchicalMappingData);
                    default:
                        break;
                }
            },

            // =================================================================================================================================================
            // 'FROM PAGE' mode
            // =================================================================================================================================================

            _getFromLinkDataList: function (/*Array*/highwaysData, /*Array*/hierarchicalMappingData, /*Object*/selectedHierarchicalContent) {
                // summary:
                //      Get the collection of the from content (page) link data object
                // highwaysData: [Array]
                //      The given data set that wanted to bind to the current component
                // hierarchicalMappingData: [Array]
                //      The given data that used to mapping a group to a desired position (x,y)
                // selectedHierarchicalContent: [Object]
                //      The given selected hierarchical content
                // returns: [$.Deferred]
                //      The jQuery Deferred object
                // tags:
                //      private

                var $deferred = $.Deferred(),
                    totalItems = highwaysData.length,
                    linkData = {},
                    linkDataList = [],
                    linkDataId,
                    source,
                    target;

                while (totalItems--) {
                    linkData = this._getLinkItemData(highwaysData[totalItems]);

                    source = utility.getItemFromCollection(hierarchicalMappingData, linkData.source, this._filterName);
                    if (source && selectedHierarchicalContent && source.contentId == selectedHierarchicalContent.contentId) {
                        linkData.contentId = source.contentId;
                        linkData.source = source;

                        target = utility.getItemFromCollection(hierarchicalMappingData, linkData.target, this._filterName);
                        if (!target) {
                            if (totalItems === 0) {
                                $deferred.resolve(linkDataList);
                                break;
                            }

                            continue;
                        }

                        linkDataId += '-' + target.contentId;
                        linkData.target = target;

                        // 'linkId' value is the combination of source content id and target content id (separated by '-' character)
                        //  It will be in the following format: sourceContentId-targetContentId
                        //  For example: '1-2'
                        linkData.linkId = linkDataId;
                        linkData && linkDataList.push(linkData);
                    }

                    if (totalItems === 0) {
                        $deferred.resolve(linkDataList);
                    }
                }

                return $deferred.promise();
            },

            // =================================================================================================================================================
            // 'TO PAGE' mode
            // =================================================================================================================================================

            _getToLinkDataList: function (/*Array*/highwaysData, /*Array*/hierarchicalMappingData, /*Object*/selectedHierarchicalContent) {
                // summary:
                //      Get the collection of the to content (page) link data object
                // highwaysData: [Array]
                //      The given data set that wanted to bind to the current component
                // hierarchicalMappingData: [Array]
                //      The given data that used to mapping a group to a desired position (x,y)
                // selectedHierarchicalContent: [Object]
                //      The given selected hierarchical content
                // returns: [$.Deferred]
                //      The jQuery Deferred object
                // tags:
                //      private

                var $deferred = $.Deferred(),
                    totalItems = highwaysData.length,
                    linkData = {},
                    linkDataList = [],
                    linkDataId,
                    source,
                    target;

                while (totalItems--) {
                    linkData = this._getLinkItemData(highwaysData[totalItems]);

                    target = utility.getItemFromCollection(hierarchicalMappingData, linkData.target, this._filterName);
                    if (target && selectedHierarchicalContent && target.contentId == selectedHierarchicalContent.contentId) {
                        linkDataId = target.contentId;
                        linkData.target = target;

                        source = utility.getItemFromCollection(hierarchicalMappingData, linkData.source, this._filterName);
                        if (!source) {
                            if (totalItems === 0) {
                                $deferred.resolve(linkDataList);
                                break;
                            }

                            continue;
                        }

                        linkDataId += '-' + source.contentId;
                        linkData.source = source;

                        // 'linkId' value is the combination of source content id and target content id (separated by '-' character)
                        //  It will be in the following format: targetContentId-sourceContentId
                        //  For example: '1-2'
                        linkData.linkId = linkDataId;
                        linkData && linkDataList.push(linkData);
                    }

                    if (totalItems === 0) {
                        $deferred.resolve(linkDataList);
                    }
                }

                return $deferred.promise();
            },

            // =================================================================================================================================================
            // 'GLOBAL' mode
            // =================================================================================================================================================

            _getGlobalLinkDataList: function (/*Array*/highwaysData, /*Array*/hierarchicalMappingData) {
                // summary:
                //      Get the collection of the global (both from and to content - page) link data object
                // highwaysData: [Array]
                //      The given data set that wanted to bind to the current component
                // hierarchicalMappingData: [Array]
                //      The given data that used to mapping a group to a desired position (x,y)
                // returns: [$.Deferred]
                //      The jQuery Deferred object
                // tags:
                //      private

                var $deferred = $.Deferred(),
                    totalItems = highwaysData.length,
                    linkData = {},
                    linkDataList = [],
                    linkDataId,
                    source,
                    target;

                while (totalItems--) {
                    linkData = this._getLinkItemData(highwaysData[totalItems]);

                    source = utility.getItemFromCollection(hierarchicalMappingData, linkData.source, this._filterName);
                    if (!source) {
                        if (totalItems === 0) {
                            $deferred.resolve(linkDataList);
                            break;
                        }

                        continue;
                    }

                    linkDataId = source.contentId;
                    linkData.source = source;

                    target = utility.getItemFromCollection(hierarchicalMappingData, linkData.target, this._filterName);
                    if (!target) {
                        if (totalItems === 0) {
                            $deferred.resolve(linkDataList);
                            break;
                        }

                        continue;
                    }

                    linkDataId += '-' + target.contentId;
                    linkData.target = target;

                    // 'linkId' value is the combination of source content id and target content id (separated by '-' character)
                    //  It will be in the following format: sourceContentId-targetContentId
                    //  For example: '1-2'
                    linkData.linkId = linkDataId;
                    linkData && linkDataList.push(linkData);

                    if (totalItems === 0) {
                        $deferred.resolve(linkDataList);
                    }
                }

                return $deferred.promise();
            },

            // =================================================================================================================================================
            // Utility functions
            // =================================================================================================================================================

            _getLinkItemData: function (/*Object*/itemData) {
                // summary:
                //      Get the link item data object from the given item data object
                // itemData: [Object]
                //      The given item data object
                // returns: [Object]
                //      The link item data object
                // tags:
                //      private

                return {
                    source: {
                        contentId: itemData.sourceId
                    },
                    target: {
                        contentId: itemData.targetId
                    },
                    transfers: itemData.count
                };
            }

        };

    // A really lightweight plugin $wrapper around the constructor, 
    //  preventing against multiple instantiations
    $.fn[pluginName] = function (/*Object*/options) {
        // summary:
        //      Create a new jQuery plugin from the given settings
        // options: [Object]
        //      The given settings that wanted to decorates the default settings of the current component
        // returns: [Object]
        //      The jQuery plugin object
        // tags:
        //      protected

        // Decorates the default settings by the given settings
        $.extend(true, pluginOptions, options);

        // Create and then return a new jQuery plugin object
        return componentFactory.create(this, pluginName, pluginDefinitions, pluginOptions);
    };

});