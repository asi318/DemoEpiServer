﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'components/ComponentFactory',

    'components/Statistic/HitsPerHour',
    'components/Statistic/ClientsPerHour',

    'data/StatisticRepository',
// resources
    'text!components/Statistic/Templates/StatisticsBar.html'
],

function (
// libs
    $,
// live monitor
    utility,

    componentFactory,

    hitsPerHour,
    clientsPerHour,

    statisticRepository,
// resources
    templateString
) {

    // =================================================================================================================================================
    // Plugin information
    // =================================================================================================================================================
    //
    // module:
    //      Components/Statistic/LiveMonitorStatisticsBar
    //
    // summary:
    //      
    // description:
    //
    //      use:
    //          $(target).LiveMonitorStatisticsBar(options);
    //
    //      options:
    //          templateString [String]
    //          baseClasses [String]
    //          children [Array]
    //
    //      required:
    //          
    //          
    // tags:
    //      public

    // Create the defaults once
    var pluginName = 'LiveMonitorStatisticsBar',
        pluginOptions = {
            templateString: templateString,
            baseClasses: 'livemonitor-statisticsBar',
            children: [],
            sender: 'trace',
            senderCallback: 'getCurrentStatistics',
            // autoCalculate [Boolean] public
            //      Flag indicates that should or should not auto calculate hits per hour
            autoCalculate: true,
            enableParam: 'isStatisticsControlsVisible'
        },
        pluginDefinitions = {

            // _interval: [Integer]
            //      Time in minisecond (is 6 minutes) to get refresh data from server side
            _interval: 360000,

            // =================================================================================================================================================
            // Overrided functions
            // =================================================================================================================================================

            _postInit: function () {
                // summary:
                //      Post-initialize settings for the component
                // tags:
                //      protected, extension

                this._repository = statisticRepository;

                this._setupLayout();
                this._requestStatisticsData();
            },

            _onAddChild: function (/*Object*/child) {
                // summary:
                //      Place to decorates the given child element
                // child: [Object]
                //      The given child element that want to decorates
                // tags:
                //      protected, extensions

                child && child.addClass('item-statisticsBar').wrap('<li></li>');
            },

            // =================================================================================================================================================
            // Public callback functions
            // =================================================================================================================================================

            onReceiveCompleted: function (/*Object*/statisticsData) {
                // summary:
                //      Fired after client requested to server and then server responsed
                // statisticsData: [Object]
                //      The given statistics data that will be used to bind to each statistic component
                //      Object's properties:
                //          lightClientsData: [Array]
                //              The collection of all the clients per hour
                //          hitsPerHour: [Integer]
                //              The total hits per hour
                //          clientsPerHour: [Integer]
                //              The total clients per hour
                // tags:
                //      public, extensions

                if (!statisticsData) {
                    return;
                }

                statisticsData = utility.getJSONObject(statisticsData);

                this._repository.clearData();
                this._repository.saveData(statisticsData);

                this._bindChildrenData();
            },

            bindData: function (/*Array*/onlineVisitorList) {
                // summary:
                //      Fired when had any change in server side
                // onlineVisitorList: [Object]
                //      The given collection of the online visitor
                // tags:
                //      public, extensions

                this._repository.saveOnlineVisitorList(onlineVisitorList);

                if (this.options.autoCalculate) {
                    this._bindChildrenData();

                    if (this._requestDataInterval) {
                        return;
                    }

                    this._requestDataInterval = setInterval(utility.hitch(this, function () {
                        this._requestDataInterval = null;
                        this._requestStatisticsData();
                    }), this._interval);
                } else {
                    this._requestStatisticsData();
                }
            },

            // =================================================================================================================================================
            // Private functions
            // =================================================================================================================================================

            _setupLayout: function () {
                // summary:
                //      Initialize default layout settings for the component
                // tags:
                //      private

                this._addDefaultStatisticItems();
            },

            _addDefaultStatisticItems: function () {
                // summary:
                //      Add default statistic items for the current component
                // tags:
                //      private

                var autoCalculate = this.options.autoCalculate;

                this._$hitsStatistic = $('<div id="livemonitor-hitsStatistic"></div>').LiveMonitorHitsPerHourStatistic({
                    resources: this._resources.hitsstatistic,
                    autoCalculate: autoCalculate
                });

                this._$clientsStatistic = $('<div id="livemonitor-clientsStatistic"></div>').LiveMonitorClientsPerHourStatistic({
                    resources: this._resources.clientsstatistic,
                    autoCalculate: autoCalculate
                });

                // Append default statistics
                this.options.children = this.options.children.length === 0
                    ? [this._$hitsStatistic, this._$clientsStatistic]
                    // Removes 0 element from index 0, and then inserts 2 new elements
                    : this.options.children.splice(/*index*/0, /*howMany*/0, this._$hitsStatistic, this._$clientsStatistic);
            },

            // =================================================================================================================================================
            // Data binding functions
            // =================================================================================================================================================

            _bindChildrenData: function () {
                // summary:
                //      Bind the given statistics data for all children of the current component
                // tags:
                //      private

                var data = this._repository.getData();
                if (!data) {
                    return;
                }

                var children = this.options.children;
                if (!utility.isValidArray(children)) {
                    return;
                }

                var totalItems = children.length,
                    item,
                    instance;

                while (totalItems--) {
                    item = children[totalItems];
                    if (!item) {
                        continue;
                    }

                    instance = utility.getInstance(item);
                    if (!instance || !$.isFunction(instance.bindData)) {
                        continue;
                    }

                    instance.bindData(data);
                }
            },

            // =================================================================================================================================================
            // Request data functions
            // =================================================================================================================================================

            _requestStatisticsData: function () {
                // summary:
                //      Send request to server in order to get the current statistics data
                // tags:
                //      private

                // Send a request to 'getCurrentStatistics' proxy function
                //  with following parameters:
                //      languageId: [String]
                //          The given language identification
                $.isFunction(this.send) && this.send();
            }
        };

    // A really lightweight plugin wrapper around the constructor, 
    //  preventing against multiple instantiations
    $.fn[pluginName] = function (/*Object*/options) {
        // summary:
        //      Create a new jQuery plugin from the given settings
        // options: [Object]
        //      The given settings that wanted to decorates the default settings of the current component
        // returns: [Object]
        //      The jQuery plugin object
        // tags:
        //      protected

        // Decorates the default settings by the given settings
        $.extend(true, pluginOptions, options);

        // Create and then return a new jQuery plugin object
        return componentFactory.create(this, pluginName, pluginDefinitions, pluginOptions);
    };

});