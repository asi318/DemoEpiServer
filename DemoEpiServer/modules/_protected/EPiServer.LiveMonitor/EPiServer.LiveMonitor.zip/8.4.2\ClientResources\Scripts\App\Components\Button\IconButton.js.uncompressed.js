﻿define([
// libs
    'jquery',
// live monitor
    'components/ComponentFactory',
// resources
    'text!components/Button/Templates/IconButton.html'
],

function (
// libs
    $,
// live monitor
    componentFactory,
// resources
    templateString
) {

    // =================================================================================================================================================
    // 'LiveMonitorIconButton' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Button/LiveMonitorIconButton'
    // summary:
    //      The jQuery plugin component for the icon button
    // description:
    //      use:
    //          $(target).LiveMonitorIconButton(options);
    //      options:
    //          resources [Object]
    //          templateString [String]
    //          baseClasses [String]
    // tags:
    //      public

    // Create the defaults once
    var pluginName = 'LiveMonitorIconButton',
        pluginOptions = {
            templateString: templateString,
            baseClasses: 'livemonitor-iconButton'
        };

    // A really lightweight plugin wrapper around the constructor, 
    //  preventing against multiple instantiations
    $.fn[pluginName] = function (/*Object*/options) {
        // summary:
        //      Create a new jQuery plugin from the given settings
        // options: [Object]
        //      The given settings that wanted to decorates the default settings of the current component
        // returns: [Object]
        //      The jQuery plugin object
        // tags:
        //      protected

        // Decorates the default settings by the given settings
        $.extend(true, pluginOptions, options);

        // Create and then return a new jQuery plugin object
        return componentFactory.create(this, pluginName, null, pluginOptions);
    };

    $.fn[pluginName].prototype.pluginOptions = pluginOptions;

});