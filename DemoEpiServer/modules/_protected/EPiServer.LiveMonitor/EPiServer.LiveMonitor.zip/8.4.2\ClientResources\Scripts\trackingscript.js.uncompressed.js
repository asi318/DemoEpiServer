﻿void(function(){{
    var tUrl = "{0}";
    // Add ?/& depending on any existing query params and add a random param (makes Back and Forward tracking work)
    tUrl += (tUrl.indexOf("?") > 0 ? "&" : "?");
    var tUrl1 = tUrl + "r=" + Math.random() + "&referrer=" + escape(document.referrer);
    document.write("<img id='LiveMonTransparentImage' src='" + tUrl1 + "' alt='' width='1' height='1'/>");

    //In Firefox, when the page is loaded from cache, only the pageshow event fires (the scripts
    //are not re-evaluated like in other browsers) and persisted is set to true. In this case, we need to
    //load the image manually so that server can detect the page load action
    window.onpageshow = function (ev) {{
        if (ev && ev.persisted){{
            document.getElementById("LiveMonTransparentImage").src = tUrl + "r=" + Math.random() + "&referrer=" + escape(document.referrer);
        }}
    }}
}}());